# test_datasets.R — tests for package data consistency

# -- default_destiny values ----------------------------------------------------

test_that("items_full has correct default_destiny for non-food items", {
  items <- whep::items_full

  fodder <- items |>
    dplyr::filter(item_cbs_code %in% c(2000, 2001, 2002, 2003))
  expect_true(all(fodder$default_destiny == "Feed", na.rm = TRUE))

  ethanol <- items |> dplyr::filter(item_cbs_code == 2659)
  expect_true(all(ethanol$default_destiny == "Other_uses", na.rm = TRUE))

  tobacco <- items |> dplyr::filter(item_cbs_code == 2671)
  expect_true(all(tobacco$default_destiny == "Other_uses", na.rm = TRUE))

  cotton <- items |> dplyr::filter(item_cbs_code == 2661)
  expect_true(all(cotton$default_destiny == "Other_uses", na.rm = TRUE))

  rubber <- items |> dplyr::filter(item_cbs_code == 2672)
  expect_true(all(rubber$default_destiny == "Other_uses", na.rm = TRUE))

  wool <- items |> dplyr::filter(item_cbs_code == 2746)
  expect_true(all(wool$default_destiny == "Other_uses", na.rm = TRUE))
})


# -- polity coverage -----------------------------------------------------------

test_that("polities includes promoted FAOSTAT-reporting countries", {
  pol <- whep::polities
  promoted <- c(
    "ATG",
    "BHS",
    "BRB",
    "BTN",
    "COM",
    "FJI",
    "GRD",
    "MAC",
    "MHL",
    "FSM",
    "NCL",
    "NRU",
    "PRI",
    "PYF",
    "SYC",
    "SLB",
    "TON",
    "TUV"
  )
  for (code in promoted) {
    expect_true(
      code %in% pol$iso3_code,
      info = paste(code, "should be a standalone polity")
    )
  }
  expect_gte(nrow(pol), 560L)
})

test_that("polity_area_crosswalk maps promoted countries to real polities", {
  crosswalk <- whep::polity_area_crosswalk

  btn <- crosswalk |>
    dplyr::filter(area_iso3c == "BTN", mapping_status == "matched")
  expect_true(nrow(btn) > 0)
  expect_true(any(grepl("^BTN-", btn$polity_code)))

  com <- crosswalk |>
    dplyr::filter(area_iso3c == "COM", mapping_status == "matched")
  expect_true(nrow(com) > 0)
  expect_true(any(grepl("^COM-", com$polity_code)))
})

test_that("CBS and FABIO area codes map to polity database rows", {
  crosswalk <- whep::polity_area_crosswalk

  cbs_unmapped <- crosswalk |>
    dplyr::filter(
      .data$cbs %in% TRUE,
      .data$mapping_status == "unmapped"
    ) |>
    dplyr::distinct(.data$area_code, .data$area_name)

  fabio_unmapped <- crosswalk |>
    dplyr::filter(
      !is.na(.data$fabio_code),
      .data$mapping_status == "unmapped"
    ) |>
    dplyr::distinct(.data$area_code, .data$area_name)

  expect_equal(nrow(cbs_unmapped), 0L)
  expect_equal(nrow(fabio_unmapped), 0L)

  # DISCOVERED from polity_type, not listed. The enumerated version named nine areas
  # — Belgium-Luxembourg (15), Netherlands Antilles (151), the six continental "Other"
  # buckets (901-906) and Rest of World (999) — and there are ELEVEN: areas 237 and
  # 249 also resolve to aggregate polities (F237-1954-1975 and F249-1918-1990, the
  # combined-reporting Viet Nam and Yemen rows), so those two went unchecked. Deriving
  # the set means an aggregate added upstream is covered without anyone editing this.
  aggregate_area_codes <- sort(unique(as.integer(
    crosswalk$polity_area_code[
      !is.na(crosswalk$polity_type) & crosswalk$polity_type == "aggregate"
    ]
  )))
  expect_gte(length(aggregate_area_codes), 9L)
  aggregate_codes <- crosswalk |>
    dplyr::filter(.data$area_code %in% aggregate_area_codes) |>
    dplyr::distinct(.data$area_code, .data$polity_code, .data$has_geometry)

  # Asserted per area, NOT as a row count. `nrow() == 9` silently encoded "each
  # of these areas maps to exactly one polity", which stopped being true the
  # moment upstream periodized a family: area 15 now maps to both BLX-1850-1999
  # and BLX-1921-1999, and 151 to ANT-1816-1960 and ANT-1961-2010, so the count
  # reached 11. A count is the wrong shape for this — the property wanted is that
  # every aggregate area resolves, whatever number of periods it resolves into.
  expect_setequal(aggregate_codes$area_code, aggregate_area_codes)
  expect_true(all(!is.na(aggregate_codes$polity_code)))
  expect_true(all(aggregate_codes$has_geometry))

  # Territories FABIO folds into Rest of World rather than reporting separately.
  #
  # Two of the six no longer fold: 69 (French Guiana) and 299 (Palestine) report data
  # of their own — 8,934 and 32,534 observed rows in the upstream alias map — so WHEP
  # routes them to GUF-* and PSE-1948-2025 instead of collapsing them. Folding an area
  # that reports data discards it into an aggregate. The remaining four genuinely have
  # no data of their own: 30 Antarctica, 152 Neutral Zone, 252 Unspecified,
  # 254 Others (adjustment). See test_row_fold_has_no_data.R for the invariant.
  row_source_codes <- c(30L, 152L, 252L, 254L)
  reattributed_codes <- c(69L, 299L)
  fabio_row_sources <- crosswalk |>
    dplyr::filter(.data$area_code %in% row_source_codes) |>
    dplyr::distinct(
      .data$area_code,
      .data$fabio_code,
      .data$polity_area_code,
      .data$polity_code,
      .data$has_geometry
    )

  # Same reasoning as above: assert the areas, not how many rows they produce.
  # This one passes as a count today only because ROW-1850-2023 has not been
  # periodized; it would break the same way if it ever were.
  expect_setequal(fabio_row_sources$area_code, row_source_codes)
  expect_true(all(fabio_row_sources$fabio_code == 999L))
  expect_true(all(fabio_row_sources$polity_area_code == 999L))
  expect_true(all(fabio_row_sources$polity_code == "ROW-1850-2023"))
  expect_true(all(fabio_row_sources$has_geometry))

  # And the two that were pulled back out must NOT be folded — bidirectional, so
  # re-burying them in the aggregate fails here rather than passing quietly.
  reattributed <- crosswalk |>
    dplyr::filter(.data$area_code %in% reattributed_codes) |>
    dplyr::distinct(.data$area_code, .data$polity_code)
  expect_setequal(reattributed$area_code, reattributed_codes)
  expect_false(any(startsWith(reattributed$polity_code, "ROW-")))
})


# -- source_flags.csv consistency ----------------------------------------------

test_that("source_flags.csv covers all source labels used in code", {
  flags <- readr::read_csv(
    system.file("extdata", "source_flags.csv", package = "whep"),
    show_col_types = FALSE
  )

  required <- c(
    "FAOSTAT_prod",
    "EuropeAgriDB",
    "fill_linear",
    "imputed_yield",
    "imputed_cbs_ratio",
    "LUH2_cropland",
    "LUH2_agriland",
    "LUH2_grassland",
    "FAOSTAT_FBS_New",
    "FAOSTAT_FBS_Old",
    "FAOSTAT_FBS_Old_scaled",
    "FAOSTAT_CBS",
    "FAOSTAT_trade",
    "fishstat_trade"
  )

  for (src in required) {
    expect_true(
      src %in% flags$source,
      info = paste(src, "must be documented in source_flags.csv")
    )
  }
})


# -- livestock coefficient dataset integrity -----------------------------------

# Helper: assert a dataset is a non-empty tibble with the
# expected columns, all of the correct type, and no generic
# column names from bad Excel parsing.
assert_clean_tibble <- function(obj, name, expected_cols, min_rows = 1L) {
  expect_true(
    tibble::is_tibble(obj),
    info = paste(name, "must be a tibble")
  )
  expect_gte(
    nrow(obj),
    min_rows,
    label = paste(name, "row count")
  )
  for (col in expected_cols) {
    expect_true(
      col %in% names(obj),
      info = paste(name, "missing column:", col)
    )
  }
  # No generic Excel-parsed column names
  bad <- grep(
    "^x\\d+$|^\\.\\.\\.\\d+$|^V\\d+$",
    names(obj)
  )
  expect_true(
    length(bad) == 0L,
    info = paste(
      name,
      "has generic column names:",
      paste(names(obj)[bad], collapse = ", ")
    )
  )
  # No list columns (Excel parsing artifact)
  list_cols <- names(obj)[vapply(obj, is.list, logical(1))]
  expect_true(
    length(list_cols) == 0L,
    info = paste(name, "has list columns:", paste(list_cols, collapse = ", "))
  )
  # No all-NA columns (sign of failed parsing)
  all_na <- names(obj)[
    vapply(obj, function(x) all(is.na(x)), logical(1))
  ]
  expect_true(
    length(all_na) == 0L,
    info = paste(name, "has all-NA columns:", paste(all_na, collapse = ", "))
  )
  # No character columns that are secretly numeric
  char_cols <- names(obj)[vapply(obj, is.character, logical(1))]
  for (cc in char_cols) {
    vals <- obj[[cc]][!is.na(obj[[cc]])]
    if (length(vals) == 0L) {
      next
    }
    numeric_share <- mean(grepl(
      "^-?[0-9]+(\\.[0-9]+)?([eE][+-]?[0-9]+)?$",
      vals
    ))
    expect_true(
      numeric_share < 0.5,
      info = paste0(
        name,
        "$",
        cc,
        " is character but ",
        round(numeric_share * 100),
        "% of values look numeric"
      )
    )
  }
}

# Helper: assert numeric columns contain only numeric values
# (not character strings that look numeric).
assert_numeric_cols <- function(obj, name, cols) {
  for (col in cols) {
    expect_true(
      is.numeric(obj[[col]]),
      info = paste(name, "column", col, "must be numeric")
    )
  }
}


test_that("gleam_field_operation_ef is a clean tibble", {
  obj <- whep::gleam_field_operation_ef
  assert_clean_tibble(
    obj,
    "gleam_field_operation_ef",
    c(
      "material_number",
      "material",
      "emission_factor_kg_co2eq_ha",
      "species_group"
    ),
    min_rows = 50L
  )
  expect_equal(ncol(obj), 4L)
  assert_numeric_cols(
    obj,
    "gleam_field_operation_ef",
    c("material_number", "emission_factor_kg_co2eq_ha")
  )
  expect_setequal(
    unique(obj$species_group),
    c("ruminant", "monogastric")
  )
  # No duplicate material within a species group
  dupes <- obj |>
    dplyr::count(material_number, species_group) |>
    dplyr::filter(n > 1L)
  expect_equal(nrow(dupes), 0L, info = "duplicate materials")
  # Emission factors must be non-negative
  expect_true(
    all(obj$emission_factor_kg_co2eq_ha >= 0, na.rm = TRUE)
  )
})

test_that("gleam_mechanization_levels is a clean tibble", {
  obj <- whep::gleam_mechanization_levels
  assert_clean_tibble(
    obj,
    "gleam_mechanization_levels",
    c(
      "country",
      "continent",
      "region",
      "feed_material",
      "mechanization_level",
      "species_group"
    ),
    min_rows = 5000L
  )
  expect_equal(ncol(obj), 6L)
  assert_numeric_cols(
    obj,
    "gleam_mechanization_levels",
    "mechanization_level"
  )
  expect_setequal(
    unique(obj$species_group),
    c("ruminant", "monogastric")
  )
  # No duplicate country + feed_material within species group
  dupes <- obj |>
    dplyr::count(country, feed_material, species_group) |>
    dplyr::filter(n > 1L)
  expect_equal(nrow(dupes), 0L, info = "duplicate keys")
  # Both species groups have multiple countries
  n_per_group <- obj |>
    dplyr::summarise(
      n = dplyr::n_distinct(country),
      .by = species_group
    )
  expect_true(all(n_per_group$n > 100L))
})

test_that("gleam_processing_transport_ef is a clean tibble", {
  obj <- whep::gleam_processing_transport_ef
  assert_clean_tibble(
    obj,
    "gleam_processing_transport_ef",
    c(
      "material_number",
      "material",
      "processing_g_co2eq_kg_dm",
      "transport_g_co2eq_kg_dm",
      "species_group"
    ),
    min_rows = 50L
  )
  expect_equal(ncol(obj), 5L)
  assert_numeric_cols(
    obj,
    "gleam_processing_transport_ef",
    c(
      "material_number",
      "processing_g_co2eq_kg_dm",
      "transport_g_co2eq_kg_dm"
    )
  )
  expect_setequal(
    unique(obj$species_group),
    c("ruminant", "monogastric")
  )
  # No NAs — asterisk-footnoted values must be parsed
  expect_true(
    all(!is.na(obj$processing_g_co2eq_kg_dm)),
    info = "processing EFs must not be NA"
  )
  expect_true(
    all(!is.na(obj$transport_g_co2eq_kg_dm)),
    info = "transport EFs must not be NA"
  )
})

test_that("gleam_crop_residue_nitrogen is a clean tibble", {
  obj <- whep::gleam_crop_residue_nitrogen
  assert_clean_tibble(
    obj,
    "gleam_crop_residue_nitrogen",
    c(
      "material_number",
      "material",
      "n_ag",
      "rbg_bio",
      "n_bg",
      "species_group"
    ),
    min_rows = 50L
  )
  expect_equal(ncol(obj), 6L)
  assert_numeric_cols(
    obj,
    "gleam_crop_residue_nitrogen",
    c("material_number", "n_ag", "rbg_bio", "n_bg")
  )
  expect_setequal(
    unique(obj$species_group),
    c("ruminant", "monogastric")
  )
  # Nitrogen values should be non-negative
  expect_true(all(obj$n_ag >= 0, na.rm = TRUE))
  expect_true(all(obj$n_bg >= 0, na.rm = TRUE))
})

test_that("gleam_fracremove is a clean tibble", {
  obj <- whep::gleam_fracremove
  assert_clean_tibble(
    obj,
    "gleam_fracremove",
    c("country", "continent", "region", "fracremove"),
    min_rows = 10L
  )
  expect_equal(ncol(obj), 4L)
  assert_numeric_cols(
    obj,
    "gleam_fracremove",
    "fracremove"
  )
  expect_true(all(obj$fracremove > 0 & obj$fracremove < 1))
  # Each country appears only once
  expect_equal(
    length(unique(obj$country)),
    nrow(obj),
    info = "country must be unique"
  )
})

test_that("gleam_energy_use_ef is a clean tibble", {
  obj <- whep::gleam_energy_use_ef
  assert_clean_tibble(
    obj,
    "gleam_energy_use_ef",
    c(
      "species",
      "herd",
      "grouping",
      "grouping_scheme",
      "system",
      "climate",
      "energy_type",
      "denominator",
      "emission_factor"
    ),
    min_rows = 100L
  )
  expect_equal(ncol(obj), 9L)
  assert_numeric_cols(
    obj,
    "gleam_energy_use_ef",
    "emission_factor"
  )
  expect_setequal(
    unique(obj$energy_type),
    c("embedded", "direct")
  )
  expect_setequal(
    unique(obj$grouping_scheme),
    c("development3", "region5", "detailed15")
  )
  expect_setequal(
    unique(obj$denominator),
    c("lw", "milk", "egg")
  )
  expected_species <- c(
    "cattle",
    "buffalo",
    "small_ruminants",
    "pigs",
    "chickens",
    "large_ruminants"
  )
  expect_true(all(obj$species %in% expected_species))
  # All species are present (no silently dropped table)
  expect_setequal(unique(obj$species), expected_species)
  # Both energy types have multiple species
  species_per_type <- obj |>
    dplyr::summarise(
      n = dplyr::n_distinct(species),
      .by = energy_type
    )
  expect_true(all(species_per_type$n >= 3L))
  # Footnote-derived rows: meat cattle embedded is half of dairy cattle.
  dairy <- obj |>
    dplyr::filter(
      species == "cattle",
      herd == "dairy",
      energy_type == "embedded"
    )
  meat <- obj |>
    dplyr::filter(
      species == "cattle",
      herd == "non_dairy",
      energy_type == "embedded"
    )
  joined <- dplyr::inner_join(
    dairy,
    meat,
    by = c("grouping", "system", "climate"),
    suffix = c("_dairy", "_meat")
  )
  expect_equal(joined$emission_factor_meat, joined$emission_factor_dairy * 0.5)
  # Emission factors must be non-negative and fully resolved (this catches the
  # middle-dot notation parsing failure for pigs and chickens).
  expect_true(all(obj$emission_factor >= 0))
  expect_false(any(is.na(obj$emission_factor)))
  # No footnote text in grouping column
  expect_false(
    any(grepl("^a\\s", obj$grouping)),
    info = "footnote rows must be filtered out"
  )
})

test_that("gleam_geographic_hierarchy has correct types", {
  obj <- whep::gleam_geographic_hierarchy
  assert_clean_tibble(
    obj,
    "gleam_geographic_hierarchy",
    c(
      "iso3",
      "country",
      "continent",
      "faostat_region",
      "gleam_region",
      "eu27",
      "oecd"
    ),
    min_rows = 200L
  )
  expect_equal(ncol(obj), 7L)
  expect_true(
    is.integer(obj$eu27),
    info = "eu27 must be integer, not character"
  )
  expect_true(
    is.integer(obj$oecd),
    info = "oecd must be integer, not character"
  )
  expect_true(all(obj$eu27 %in% c(0L, 1L)))
  expect_true(all(obj$oecd %in% c(0L, 1L)))
  # ISO3 codes should be unique and 3 characters
  expect_equal(
    length(unique(obj$iso3)),
    nrow(obj),
    info = "iso3 must be unique"
  )
  expect_true(
    all(nchar(obj$iso3) == 3L),
    info = "iso3 must be 3 characters"
  )
  # No footnotes leaked in as data rows
  expect_false(
    any(grepl("^http|^Source|^List", obj$iso3)),
    info = "footnote rows must be filtered out"
  )
})

test_that("gleam_crop_residue_params is a clean tibble", {
  obj <- whep::gleam_crop_residue_params
  assert_clean_tibble(
    obj,
    "gleam_crop_residue_params",
    c("crop", "dry_matter_pct", "slope", "intercept"),
    min_rows = 15L
  )
  expect_equal(ncol(obj), 4L)
  assert_numeric_cols(
    obj,
    "gleam_crop_residue_params",
    c("dry_matter_pct", "slope", "intercept")
  )
})

test_that("gleam_feed_composition is a clean tibble", {
  obj <- whep::gleam_feed_composition
  assert_clean_tibble(
    obj,
    "gleam_feed_composition",
    c(
      "feed_group",
      "feed_type",
      "gleam_region",
      "feed_use_efficiency"
    ),
    min_rows = 15L
  )
  expect_equal(ncol(obj), 4L)
  assert_numeric_cols(
    obj,
    "gleam_feed_composition",
    "feed_use_efficiency"
  )
})

test_that("gleam_feed_digestibility is a clean tibble", {
  obj <- whep::gleam_feed_digestibility
  assert_clean_tibble(
    obj,
    "gleam_feed_digestibility",
    c(
      "number",
      "material",
      "gross_energy_mj_kg",
      "n_content_g_kg",
      "digestibility_pct"
    ),
    min_rows = 20L
  )
  expect_equal(ncol(obj), 5L)
  assert_numeric_cols(
    obj,
    "gleam_feed_digestibility",
    c("gross_energy_mj_kg", "n_content_g_kg", "digestibility_pct")
  )
})

test_that("gleam_feed_conversion_ratios is a clean tibble", {
  obj <- whep::gleam_feed_conversion_ratios
  assert_clean_tibble(
    obj,
    "gleam_feed_conversion_ratios",
    c(
      "number",
      "material",
      "gross_energy_j_kg",
      "n_content_g_kg",
      "me_chicken_j_kg",
      "me_pigs_j_kg",
      "digestibility_pct"
    ),
    min_rows = 30L
  )
  expect_equal(ncol(obj), 7L)
  assert_numeric_cols(
    obj,
    "gleam_feed_conversion_ratios",
    c("gross_energy_j_kg", "n_content_g_kg")
  )
})

test_that("gleam_dressing_percentages is a clean tibble", {
  obj <- whep::gleam_dressing_percentages
  assert_clean_tibble(
    obj,
    "gleam_dressing_percentages",
    c(
      "species",
      "production_system",
      "cohort",
      "gleam_region",
      "dressing_percent"
    ),
    min_rows = 100L
  )
  expect_equal(ncol(obj), 6L)
  assert_numeric_cols(
    obj,
    "gleam_dressing_percentages",
    "dressing_percent"
  )
  # Dressing percent should be 0–100 range
  non_na <- obj$dressing_percent[!is.na(obj$dressing_percent)]
  expect_true(all(non_na >= 0 & non_na <= 100))
  # Has both regional (country = NA) and country-specific rows
  expect_true(any(is.na(obj$country)))
  expect_true(any(!is.na(obj$country)))
})

test_that("gleam_livestock_categories is a clean tibble", {
  obj <- whep::gleam_livestock_categories
  assert_clean_tibble(
    obj,
    "gleam_livestock_categories",
    c("species", "production_system", "cohort", "description"),
    min_rows = 20L
  )
})

test_that("gleam_enteric_params is a clean tibble", {
  obj <- whep::gleam_enteric_params
  assert_clean_tibble(
    obj,
    "gleam_enteric_params",
    c("species", "system", "ym_percent"),
    min_rows = 5L
  )
  assert_numeric_cols(
    obj,
    "gleam_enteric_params",
    "ym_percent"
  )
})

test_that("gleam_mms_shares is a clean tibble", {
  obj <- whep::gleam_mms_shares
  assert_clean_tibble(
    obj,
    "gleam_mms_shares",
    c("region", "species", "system", "mms", "share_percent"),
    min_rows = 10L
  )
  assert_numeric_cols(
    obj,
    "gleam_mms_shares",
    "share_percent"
  )
})

test_that("gleam_animal_weights is a clean tibble", {
  obj <- whep::gleam_animal_weights
  assert_clean_tibble(
    obj,
    "gleam_animal_weights",
    c("region", "species", "system", "cohort", "weight_kg"),
    min_rows = 15L
  )
  assert_numeric_cols(
    obj,
    "gleam_animal_weights",
    "weight_kg"
  )
})

test_that("gleam_milk_production is a clean tibble", {
  obj <- whep::gleam_milk_production
  assert_clean_tibble(
    obj,
    "gleam_milk_production",
    c("region", "species", "system", "milk_kg_head_yr", "lactation_days"),
    min_rows = 5L
  )
  assert_numeric_cols(
    obj,
    "gleam_milk_production",
    c("milk_kg_head_yr", "lactation_days")
  )
})

# -- IPCC datasets integrity --------------------------------------------------

test_that("IPCC 2019 datasets are clean tibbles", {
  ipcc_datasets <- list(
    ipcc_2019_enteric_ef_cattle = c(
      "category",
      "ef_kg_head_yr"
    ),
    ipcc_2019_enteric_ef_other = c(
      "category",
      "ef_kg_head_yr"
    ),
    ipcc_2019_manure_ch4_ef_cattle = c("category"),
    ipcc_2019_manure_ch4_ef_other = c("category"),
    ipcc_2019_mcf_manure = c("system", "mcf_percent"),
    ipcc_2019_n_excretion = c(
      "category",
      "nex_kg_n_head_yr"
    ),
    ipcc_2019_n2o_ef_direct = c(
      "system",
      "ef_kg_n2o_n_per_kg_n"
    ),
    ipcc_2019_ym = c("category", "ym_percent"),
    ipcc_2019_bo = c("category", "bo_m3_kg_vs"),
    ipcc_2019_cfi = c("category", "cfi_mj_day_kg075")
  )

  for (nm in names(ipcc_datasets)) {
    obj <- getExportedValue("whep", nm)
    assert_clean_tibble(obj, nm, ipcc_datasets[[nm]])
    has_numeric <- any(vapply(
      obj,
      is.numeric,
      logical(1)
    ))
    expect_true(
      has_numeric,
      info = paste(nm, "must have numeric columns")
    )
  }
})

test_that("IPCC 2006 datasets are clean tibbles", {
  ipcc_2006 <- list(
    ipcc_2006_enteric_ef = c(
      "category",
      "ef_kg_head_yr"
    ),
    ipcc_2006_manure_ef = c(
      "category",
      "ef_kg_head_yr"
    ),
    ipcc_2006_mcf_temp = c("system", "mcf_percent")
  )
  for (nm in names(ipcc_2006)) {
    obj <- getExportedValue("whep", nm)
    assert_clean_tibble(obj, nm, ipcc_2006[[nm]])
  }
})

test_that("IPCC Tier 2 datasets are clean tibbles", {
  tier2 <- c(
    "ipcc_tier2_energy_coefs",
    "ipcc_tier2_ym_values",
    "ipcc_tier2_bo_values",
    "ipcc_tier2_manure_ash",
    "ipcc_tier2_n_retention"
  )
  for (nm in tier2) {
    obj <- getExportedValue("whep", nm)
    expect_true(
      tibble::is_tibble(obj),
      info = paste(nm, "must be a tibble")
    )
    expect_gte(nrow(obj), 1L, label = nm)
    has_numeric <- any(vapply(
      obj,
      is.numeric,
      logical(1)
    ))
    expect_true(
      has_numeric,
      info = paste(nm, "must have numeric columns")
    )
  }
})

# -- Other livestock coefficient datasets --------------------------------------

test_that("livestock_production_defaults is a clean tibble", {
  obj <- whep::livestock_production_defaults
  assert_clean_tibble(
    obj,
    "livestock_production_defaults",
    expected_cols = character(0),
    min_rows = 5L
  )
})

test_that("feed_characteristics is a clean tibble", {
  obj <- whep::feed_characteristics
  assert_clean_tibble(
    obj,
    "feed_characteristics",
    expected_cols = character(0),
    min_rows = 2L
  )
})

test_that("smil_2001_synthetic_n_global covers 1913-2000", {
  obj <- whep::smil_2001_synthetic_n_global
  assert_clean_tibble(
    obj,
    "smil_2001_synthetic_n_global",
    expected_cols = c("year", "global_kt_n"),
    min_rows = 10L
  )
  expect_equal(min(obj$year), 1913L)
  expect_equal(max(obj$year), 2000L)
  # Monotone growth between WWII recovery (1945) and 2000.
  recovery <- obj |> dplyr::filter(year >= 1945, year <= 2000)
  expect_true(all(diff(recovery$global_kt_n) > 0))
  # Haber-Bosch first commercial year (1913) is the smallest anchor.
  expect_equal(obj$global_kt_n[obj$year == 1913L], min(obj$global_kt_n))
})

test_that("livestock_constants is a named list", {
  obj <- whep::livestock_constants
  expect_true(is.list(obj))
  expect_true(
    all(vapply(obj, is.numeric, logical(1)))
  )
  expect_true("energy_content_ch4_mj_kg" %in% names(obj))
  expect_true("days_in_year" %in% names(obj))
})


# -- mapping key uniqueness (issue #178) ---------------------------------------

# A non-unique join key silently fans out downstream merges; a fully
# duplicated row double-counts. Assert both invariants on the shipped
# mapping tables. NA keys are allowed (unmapped rows), but non-NA keys
# must be unique.
assert_unique_key <- function(obj, name, key) {
  values <- obj[[key]]
  dup_keys <- unique(values[!is.na(values) & duplicated(values)])
  expect_true(
    length(dup_keys) == 0L,
    info = paste(
      name,
      "has non-unique key",
      key,
      "-",
      paste(dup_keys, collapse = ", ")
    )
  )
  expect_equal(
    nrow(obj),
    nrow(dplyr::distinct(obj)),
    label = paste(name, "has fully duplicated rows")
  )
}

test_that("mapping tables have unique keys and no duplicate rows", {
  assert_unique_key(whep::items_prod_full, "items_prod_full", "item_prod_code")
  assert_unique_key(whep::items_full, "items_full", "item_cbs_code")
  assert_unique_key(whep::regions_full, "regions_full", "code")
  assert_unique_key(whep::cbs_trade_codes, "cbs_trade_codes", "item_code_trade")
  assert_unique_key(whep::animals_codes, "animals_codes", "item_cbs_code")
})

test_that("FAOSTAT production code 1807 maps only to Sheep and Goat Meat", {
  # Verified against FAOSTAT: 1807 = Sheep and Goat Meat,
  # Citrus Fruit, Total = 1804 (issue #178).
  at_1807 <- whep::items_prod_full |>
    dplyr::filter(item_prod_code == 1807)
  expect_equal(nrow(at_1807), 1L)
  expect_equal(at_1807$item_prod, "Sheep and Goat Meat")

  citrus <- whep::items_prod_full |>
    dplyr::filter(item_prod == "Citrus Fruit, Total")
  expect_equal(citrus$item_prod_code, "1804")
})
