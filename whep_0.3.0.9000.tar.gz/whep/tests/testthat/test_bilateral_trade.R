# Integration / regression tests -----------------------------------------------

testthat::test_that("get_bilateral_trade returns expected structure", {
  result <- get_bilateral_trade(example = TRUE)

  testthat::expect_s3_class(result, "tbl_df")
  testthat::expect_named(
    result,
    c("year", "item_cbs_code", "bilateral_trade")
  )
  testthat::expect_equal(nrow(result), 10)
  testthat::expect_true(all(
    purrr::map_lgl(result$bilateral_trade, is.matrix)
  ))

  # Every matrix must be square 187x187
  purrr::walk(result$bilateral_trade, function(m) {
    testthat::expect_equal(nrow(m), 187)
    testthat::expect_equal(ncol(m), 187)
  })
})

testthat::test_that("get_bilateral_trade example has expected content", {
  result <- get_bilateral_trade(example = TRUE)

  # All 10 groups should have matrices filled with 1s
  purrr::walk(result$bilateral_trade, function(m) {
    testthat::expect_true(all(m == 1))
  })

  # Check known year/item combinations exist
  testthat::expect_true(
    any(result$year == 2003 & result$item_cbs_code == 2552)
  )
  testthat::expect_true(
    any(result$year == 2015 & result$item_cbs_code == 2672)
  )
})

# Unit tests -------------------------------------------------------------------

testthat::test_that(".prefer_flow_direction chooses preferred trade data", {
  bilateral_trade <- tibble::tribble(
    ~from_code, ~to_code, ~year, ~item_cbs_code, ~element, ~value,
    1, 2, 2000, 1, "Import", 0,
    1, 2, 2000, 1, "Export", 0,
    1, 2, 2000, 2, "Export", 0,
    1, 3, 2000, 2, "Import", 0,
    2, 3, 2000, 2, "Import", 0,
    2, 3, 2001, 2, "Export", 0,
    2, 3, 2001, 2, "Import", 0,
  ) |>
    dplyr::arrange(from_code, to_code, year, item_cbs_code)

  brute_group_by_result <- bilateral_trade |>
    dplyr::group_by(from_code, to_code, year, item_cbs_code) |>
    dplyr::filter(dplyr::n() == 1 | element == "Import") |>
    dplyr::ungroup() |>
    dplyr::arrange(from_code, to_code, year, item_cbs_code)

  my_result <- .prefer_flow_direction(bilateral_trade, "Import") |>
    dplyr::arrange(from_code, to_code, year, item_cbs_code)

  expected_import_result <- tibble::tribble(
    ~from_code, ~to_code, ~year, ~item_cbs_code, ~element, ~value,
    1, 2, 2000, 1, "Import", 0,
    1, 2, 2000, 2, "Export", 0,
    1, 3, 2000, 2, "Import", 0,
    2, 3, 2000, 2, "Import", 0,
    2, 3, 2001, 2, "Import", 0,
  ) |>
    dplyr::arrange(from_code, to_code, year, item_cbs_code)

  testthat::expect_equal(my_result, brute_group_by_result)
  testthat::expect_equal(my_result, expected_import_result)

  brute_group_by_result <- bilateral_trade |>
    dplyr::group_by(from_code, to_code, year, item_cbs_code) |>
    dplyr::filter(dplyr::n() == 1 | element == "Export") |>
    dplyr::ungroup() |>
    dplyr::arrange(from_code, to_code, year, item_cbs_code)

  my_result <- .prefer_flow_direction(bilateral_trade, "Export") |>
    dplyr::arrange(from_code, to_code, year, item_cbs_code)

  expected_export_result <- tibble::tribble(
    ~from_code, ~to_code, ~year, ~item_cbs_code, ~element, ~value,
    1, 2, 2000, 1, "Export", 0,
    1, 2, 2000, 2, "Export", 0,
    1, 3, 2000, 2, "Import", 0,
    2, 3, 2000, 2, "Import", 0,
    2, 3, 2001, 2, "Export", 0,
  ) |>
    dplyr::arrange(from_code, to_code, year, item_cbs_code)

  testthat::expect_equal(my_result, brute_group_by_result)
  testthat::expect_equal(my_result, expected_export_result)
})

testthat::test_that(".estimate_bilateral_trade creates expected matrix", {
  exports <- c(5, 0, 4)
  imports <- c(1, 3, 0)
  expected <- matrix(
    # fmt: skip
    c(
      0.9027778, 2.708333, 0,
      0.0000000, 0.000000, 0,
      0.7222222, 2.166667, 0
    ),
    byrow = TRUE,
    ncol = 3
  )
  result <- .estimate_bilateral_trade(exports, imports)
  testthat::expect_equal(result, expected, tolerance = 1e-6)

  # Martin' slide example
  exports <- c(500, 300, 100, 0, 0, 0)
  imports <- c(200, 150, 120, 200, 190, 30)
  expected <- matrix(
    # fmt: skip
    c(
      112, 84, 67, 112, 106, 17,
      67, 50, 40, 67, 64, 10,
      22, 17, 13, 22, 21, 3,
      0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0
    ),
    byrow = TRUE,
    ncol = 6
  )
  result <- .estimate_bilateral_trade(exports, imports)
  testthat::expect_equal(result, expected, tolerance = 1)

  # No data imports sum 0
  exports <- c(5, 0, 4)
  imports <- c(0, 0, 0)
  expected <- matrix(
    # fmt: skip
    c(
      0, 0, 0,
      0, 0, 0,
      0, 0, 0
    ),
    byrow = TRUE,
    ncol = 3
  )
  result <- .estimate_bilateral_trade(exports, imports)
  testthat::expect_equal(result, expected, tolerance = 1)

  # No data exports sum 0
  exports <- c(0, 0, 0)
  imports <- c(1, 3, 0)
  expected <- matrix(
    # fmt: skip
    c(
      0, 0, 0,
      0, 0, 0,
      0, 0, 0
    ),
    byrow = TRUE,
    ncol = 3
  )
  result <- .estimate_bilateral_trade(exports, imports)
  testthat::expect_equal(result, expected, tolerance = 1)

  # No data both sum 0
  exports <- c(0, 0, 0)
  imports <- c(0, 0, 0)
  expected <- matrix(
    # fmt: skip
    c(
      0, 0, 0,
      0, 0, 0,
      0, 0, 0
    ),
    byrow = TRUE,
    ncol = 3
  )
  result <- .estimate_bilateral_trade(exports, imports)
  testthat::expect_equal(result, expected, tolerance = 1)
})

testthat::test_that(".fill_missing_trade only fills NA entries of matrix", {
  original <- matrix(
    # fmt: skip
    c(
      140, NA, NA,
      50, 100, NA,
      NA, NA, NA
    ),
    byrow = TRUE,
    ncol = 3
  )

  # Regression for #152: a country never trades with itself, so the
  # diagonal is always forced to 0 -- including the pre-existing 140/100
  # values at [1,1]/[2,2], which .fill_missing_trade() now treats as
  # self-trade rather than ordinary (non-NA, left-alone) cells.
  expected <- matrix(
    # fmt: skip
    c(
      0.00, 7.65, 2.45,
      50.00, 0.00, 2.96,
      3.64, 4.55, 0.00
    ),
    byrow = TRUE,
    ncol = 3
  )
  total_trade <- tibble::tribble(
    ~area_code, ~export, ~import,
    4, 250, 200,
    6, 200, 250,
    7, 100, 80
  ) |>
    .balance_total_trade()

  original |>
    .fill_missing_trade(total_trade) |>
    testthat::expect_equal(expected, tolerance = 1e-2)
})

testthat::test_that(".fill_missing_trade zeroes the diagonal even when the rest is unchanged", {
  original <- matrix(
    # fmt: skip
    c(
      140, 40, 30,
      50, 100, 77,
      11, 324, 23
    ),
    byrow = TRUE,
    ncol = 3
  )
  # Regression for #152: off-diagonal non-NA cells stay untouched, but the
  # diagonal (self-trade) is always forced to 0.
  expected <- matrix(
    # fmt: skip
    c(
      0, 40, 30,
      50, 0, 77,
      11, 324, 0
    ),
    byrow = TRUE,
    ncol = 3
  )
  total_trade <- tibble::tribble(
    ~area_code, ~export, ~import,
    4, 250, 250,
    6, 300, 550,
    7, 450, 150
  ) |>
    .balance_total_trade()

  original |>
    .fill_missing_trade(total_trade) |>
    testthat::expect_equal(expected, tolerance = 1e-2)
})

testthat::test_that(".fill_missing_trade fills with 0s if row sum is already past CBS report", {
  original <- matrix(
    # fmt: skip
    c(
      140, NA,
      NA, 100
    ),
    byrow = TRUE,
    ncol = 2
  )
  # Regression for #152: both diagonal entries are forced to 0 (self-trade),
  # on top of the pre-existing "row sum already past target" 0-fill.
  expected <- matrix(
    # fmt: skip
    c(
      0, 0,
      0, 0
    ),
    byrow = TRUE,
    ncol = 2
  )
  total_trade <- tibble::tribble(
    ~area_code, ~export, ~import,
    4, 130, 200,
    6, 90, 100,
  ) |>
    .balance_total_trade()

  original |>
    .fill_missing_trade(total_trade) |>
    testthat::expect_equal(expected, tolerance = 1e-2)
})

testthat::test_that(".balance_matrix makes rows and columns have target sum", {
  total_trade <- tibble::tibble(
    area_code = c(4, 6, 7, 9, 10, 75),
    export = c(500, 300, 100, 0, 0, 0),
    import = c(200, 150, 120, 200, 190, 30)
  ) |>
    .balance_total_trade()

  trade_matrix <- matrix(
    # fmt: skip
    c(
      140, 30, 34, 140, 120, 8,
      50, 100, 20, 50, 60, 5,
      11, 8, 50, 11, 11, 2,
      0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0
    ),
    byrow = TRUE,
    ncol = 6
  )
  dimnames(trade_matrix) <- list(
    as.character(total_trade$area_code),
    as.character(total_trade$area_code)
  )

  # Rescaling exports to match total sum of 890 imports
  balanced_total_exports <- c(494.44, 296.67, 98.89, 0, 0, 0)
  balanced_total_imports <- c(200, 150, 120, 200, 190, 30)

  result <- .balance_matrix(trade_matrix, total_trade)
  testthat::expect_equal(dimnames(result), dimnames(trade_matrix))
  testthat::expect_equal(
    as.numeric(rowSums(result)),
    balanced_total_exports,
    tolerance = 1e-2
  )
  testthat::expect_equal(
    as.numeric(colSums(result)),
    balanced_total_imports,
    tolerance = 1e-2
  )
})

testthat::test_that(".balance_matrix aligns targets by country code", {
  total_trade <- tibble::tibble(
    area_code = factor(c(2, 3, 1)),
    export = c(0, 0, 10),
    import = c(10, 0, 0)
  ) |>
    .balance_total_trade()

  trade_matrix <- matrix(
    1,
    nrow = 3,
    ncol = 3,
    dimnames = list(c("1", "2", "3"), c("1", "2", "3"))
  )

  result <- .balance_matrix(trade_matrix, total_trade)

  testthat::expect_equal(as.numeric(rowSums(result)), c(10, 0, 0))
  testthat::expect_equal(as.numeric(colSums(result)), c(0, 10, 0))
})

testthat::test_that(".balance_matrix never allocates self-trade on the diagonal", {
  # Regression for #152: .fill_missing_trade()'s na_mask includes the
  # diagonal, so a large trader (big exports AND big imports) previously got
  # a spurious i -> i flow seeded by .estimate_bilateral_trade() and then
  # preserved (often inflated) by IPF's sub[sub == 0] <- 1 seeding step,
  # stealing mass from its real trading partners. Uses a matrix that
  # reproduces the exact reported failure mode: country 1 is the largest
  # trader (1000 export / 900 import) with a mostly-unobserved (NA) row.
  n <- 4
  code_int <- c(10L, 20L, 30L, 40L)
  btd <- tibble::tribble(
    ~from_code, ~to_code, ~value,
    10L, 20L, 500,
    10L, 30L, 300,
    20L, 10L, 400,
    30L, 10L, 200,
    40L, 20L, 50
  )
  total_trade <- tibble::tribble(
    ~area_code, ~export, ~import, ~balanced_export, ~balanced_import,
    10L, 1000, 900, 1000, 900,
    20L, 200, 700, 200, 700,
    30L, 150, 350, 150, 350,
    40L, 80, 100, 80, 100
  )

  result <- btd |>
    .build_trade_matrix(n, code_int) |>
    .fill_missing_trade(total_trade) |>
    .balance_matrix(total_trade)

  testthat::expect_equal(as.numeric(diag(result)), rep(0, n))
})

testthat::test_that(".build_trade_matrix completes missing countries", {
  code_int <- c(1L, 2L, 4L, 5L, 999L)
  code_levels <- as.character(code_int)
  n <- length(code_int)
  btd <- tibble::tribble(
    ~from_code, ~to_code, ~value,
    1L, 2L, 1,
    1L, 4L, 2,
    4L, 2L, 1,
    5L, 4L, 2
  )
  expected <- matrix(
    # fmt: skip
    c(
      NA, 1, 2, NA, NA,
      NA, NA, NA, NA, NA,
      NA, 1, NA, NA, NA,
      NA, NA, 2, NA, NA,
      NA, NA, NA, NA, NA
    ),
    byrow = TRUE,
    ncol = 5,
    dimnames = list(code_levels, code_levels)
  )

  btd |>
    .build_trade_matrix(n, code_int) |>
    testthat::expect_equal(expected)
})

testthat::test_that(".build_trade_matrix sums duplicate country pairs", {
  code_int <- c(1L, 2L, 3L)
  n <- length(code_int)
  btd <- tibble::tribble(
    ~from_code, ~to_code, ~value,
    1L, 2L, 3,
    1L, 2L, 4,
    2L, 3L, 5
  )

  result <- .build_trade_matrix(btd, n, code_int)

  testthat::expect_equal(result["1", "2"], 7)
  testthat::expect_equal(result["2", "3"], 5)
})

testthat::test_that(".ipf_2d converges to target margins", {
  seed <- matrix(1, nrow = 3, ncol = 3)
  target_rows <- c(10, 20, 30)
  target_cols <- c(15, 25, 20)
  result <- .ipf_2d(seed, target_rows, target_cols)

  testthat::expect_equal(
    rowSums(result),
    target_rows,
    tolerance = 0.1
  )
  testthat::expect_equal(
    colSums(result),
    target_cols,
    tolerance = 0.1
  )
})

testthat::test_that(".ipf_2d handles unequal seed values", {
  seed <- matrix(
    c(5, 1, 3, 2, 4, 1, 1, 2, 6),
    nrow = 3,
    byrow = TRUE
  )
  target_rows <- c(100, 80, 120)
  target_cols <- c(90, 110, 100)
  result <- .ipf_2d(seed, target_rows, target_cols)

  testthat::expect_equal(
    rowSums(result),
    target_rows,
    tolerance = 0.1
  )
  testthat::expect_equal(
    colSums(result),
    target_cols,
    tolerance = 0.1
  )
})

testthat::test_that(".ipf_2d handles zero rows gracefully", {
  seed <- matrix(
    c(1, 1, 0, 0, 1, 1),
    nrow = 2,
    byrow = TRUE
  )
  target_rows <- c(10, 0)
  target_cols <- c(5, 5, 0)
  result <- .ipf_2d(seed, target_rows, target_cols)

  testthat::expect_equal(
    rowSums(result),
    target_rows,
    tolerance = 0.1
  )
  testthat::expect_equal(
    result[2, ],
    c(0, 0, 0),
    tolerance = 0.1
  )
})

testthat::test_that(".complete_total_trade fills missing codes", {
  codes <- factor(c(10, 20, 30))
  total_trade <- tibble::tribble(
    ~year, ~item_cbs_code, ~area_code, ~export, ~import,
    2000, 1, codes[1], 5, 3,
    2000, 1, codes[2], 2, 4
  )

  result <- .complete_total_trade(total_trade, codes)

  testthat::expect_equal(nrow(result), 3)
  result_30 <- result |>
    dplyr::filter(area_code == 30)
  testthat::expect_equal(
    result_30$export,
    0
  )
  testthat::expect_equal(
    result_30$import,
    0
  )
})

testthat::test_that(".complete_total_trade handles multiple year-item combos", {
  codes <- factor(c(10, 20))
  total_trade <- tibble::tribble(
    ~year, ~item_cbs_code, ~area_code, ~export, ~import,
    2000, 1, codes[1], 5, 3,
    2001, 2, codes[1], 8, 1
  )
  result <- .complete_total_trade(total_trade, codes)

  testthat::expect_equal(nrow(result), 4)
})

testthat::test_that(".get_all_country_codes returns unique sorted", {
  btd <- tibble::tibble(
    from_code = c(1, 2, 3),
    to_code = c(2, 4, 5)
  )
  cbs <- tibble::tibble(area_code = c(1, 6))
  result <- .get_all_country_codes(btd, cbs)

  testthat::expect_equal(
    as.integer(result),
    c(1, 2, 3, 4, 5, 6)
  )
  testthat::expect_s3_class(result, "factor")
})

testthat::test_that(".filter_only_items_in_cbs removes items not in cbs", {
  btd <- tibble::tribble(
    ~item_cbs_code, ~value,
    1, 10,
    2, 20,
    3, 30
  )
  cbs <- tibble::tibble(item_cbs_code = c(1, 3))
  result <- .filter_only_items_in_cbs(btd, cbs)

  testthat::expect_equal(nrow(result), 2)
  items <- result |> dplyr::pull(item_cbs_code)
  testthat::expect_true(all(items %in% c(1, 3)))
})

testthat::test_that(".downscale_estimate_matrix scales rows exceeding balance", {
  estimates <- matrix(
    c(6, 4, 3, 7),
    nrow = 2,
    byrow = TRUE
  )
  balances <- c(5, 10)
  result <- .downscale_estimate_matrix(estimates, balances)

  testthat::expect_equal(rowSums(result), c(5, 10))
  testthat::expect_equal(
    result[1, 1],
    5 * 6 / 10,
    tolerance = 1e-6
  )
})

testthat::test_that(".downscale_estimate_matrix leaves small rows unchanged", {
  estimates <- matrix(
    c(2, 1, 3, 4),
    nrow = 2,
    byrow = TRUE
  )
  balances <- c(10, 20)
  result <- .downscale_estimate_matrix(estimates, balances)

  testthat::expect_equal(result, estimates)
})

testthat::test_that(".prefer_flow_direction numeric key handles large codes", {
  bilateral_trade <- tibble::tribble(
    ~from_code, ~to_code, ~year, ~item_cbs_code, ~element, ~value,
    999, 998, 2025, 2999, "Import", 10,
    999, 998, 2025, 2999, "Export", 20,
    1,   2,   1961, 2500, "Import", 5,
  )

  result <- .prefer_flow_direction(bilateral_trade, "Export") |>
    dplyr::arrange(from_code, to_code, year, item_cbs_code)

  testthat::expect_equal(nrow(result), 2)
  testthat::expect_equal(result$value, c(5, 20))
})

testthat::test_that(".prefer_flow_direction keeps all when no conflict", {
  bilateral_trade <- tibble::tribble(
    ~from_code, ~to_code, ~year, ~item_cbs_code, ~element, ~value,
    1, 2, 2000, 1, "Export", 10,
    3, 4, 2000, 1, "Import", 20,
    5, 6, 2001, 2, "Export", 30,
  )

  result <- .prefer_flow_direction(bilateral_trade, "Export")
  testthat::expect_equal(nrow(result), 3)
})

testthat::test_that(".ipf_2d converges on larger matrix", {
  set.seed(42)
  n <- 50
  seed <- matrix(abs(rnorm(n * n)), nrow = n, ncol = n)
  target_rows <- abs(rnorm(n, 100, 30))
  target_cols <- target_rows * sum(target_rows) / sum(target_rows)
  # Rescale so sums match
  target_cols <- target_cols * sum(target_rows) / sum(target_cols)

  result <- .ipf_2d(seed, target_rows, target_cols)

  testthat::expect_equal(rowSums(result), target_rows, tolerance = 0.1)
  testthat::expect_equal(colSums(result), target_cols, tolerance = 0.1)
})

testthat::test_that(".balance_matrix returns zero matrix when all trade is zero", {
  total_trade <- tibble::tibble(
    area_code = c(1, 2, 3),
    export = c(0, 0, 0),
    import = c(0, 0, 0)
  ) |>
    .balance_total_trade()

  trade_matrix <- matrix(0, nrow = 3, ncol = 3)
  result <- .balance_matrix(trade_matrix, total_trade)

  testthat::expect_equal(result, matrix(0, nrow = 3, ncol = 3))
})

testthat::test_that(".balance_matrix handles single active country", {
  total_trade <- tibble::tibble(
    area_code = c(1, 2, 3),
    export = c(10, 0, 0),
    import = c(0, 10, 0)
  ) |>
    .balance_total_trade()

  trade_matrix <- matrix(1, nrow = 3, ncol = 3)
  result <- .balance_matrix(trade_matrix, total_trade)

  testthat::expect_equal(
    sum(result),
    sum(total_trade$balanced_export),
    tolerance = 0.1
  )
})

testthat::test_that(".estimate_bilateral_trade uses tcrossprod correctly", {
  exports <- c(10, 20)
  imports <- c(5, 15)
  result <- .estimate_bilateral_trade(exports, imports)

  sum_exp <- sum(exports)
  sum_imp <- sum(imports)
  scale <- (1 / sum_imp + 1 / sum_exp) / 2
  expected <- outer(exports, imports) * scale

  testthat::expect_equal(result, expected, tolerance = 1e-10)
})

testthat::test_that(".fill_missing_trade handles all-NA matrix", {
  original <- matrix(NA_real_, nrow = 3, ncol = 3)
  total_trade <- tibble::tribble(
    ~area_code, ~export, ~import,
    1, 100, 80,
    2, 50, 120,
    3, 50, 0
  ) |>
    .balance_total_trade()

  result <- .fill_missing_trade(original, total_trade)

  testthat::expect_true(all(!is.na(result)))
  testthat::expect_true(all(result >= 0))
})


testthat::test_that(".balance_total_trade rescales larger side", {
  total_trade <- tibble::tribble(
    ~area_code, ~export, ~import,
    1, 100, 50,
    2, 200, 100
  )
  result <- .balance_total_trade(total_trade)

  pointblank::expect_col_exists(
    result,
    columns = c("balanced_export", "balanced_import")
  )
  testthat::expect_equal(
    sum(result$balanced_export),
    sum(result$balanced_import),
    tolerance = 1e-6
  )
  testthat::expect_equal(
    result$balanced_import,
    c(50, 100)
  )
})
