#' Bilateral trade data
#'
#' @description
#' Reports trade between pairs of countries in given years.
#'
#' @param example If `TRUE`, return a small example output without
#'   downloading remote data. Default is `FALSE`.
#' @param cbs Optional pre-computed wide CBS tibble from
#'   [get_wide_cbs()]. If `NULL` (default), it is built internally.
#'
#' @returns
#' A tibble with the reported trade between countries. For efficient
#' memory usage, the tibble is not exactly in tidy format.
#' It contains the following columns:
#' - `year`: The year in which the recorded event occurred.
#' - `item_cbs_code`: FAOSTAT internal code for the item that is being traded.
#'   For code details see e.g. `add_item_cbs_name()`.
#' - `bilateral_trade`: Square matrix of `NxN` dimensions where `N` is the
#'   total number of countries being considered. The matrix row and column
#'   names are exactly equal and they represent country codes.
#'   - Row name: The code of the country where the data is from. For code
#'    details see e.g. `add_area_name()`.
#'   - Column name: FAOSTAT internal code for the country that is importing the
#'     item. See row name explanation above.
#'
#'   If `m` is the matrix, the value at `m["A", "B"]` is the trade in tonnes
#'   from country `"A"` to country `"B"`, for the corresponding year and item.
#'   The matrix can be considered _balanced_. This means:
#'   - The sum of all values from row `"A"`, where `"A"` is any country,
#'     should match the total exports from country `"A"` reported in the
#'     commodity balance sheet (which is considered more accurate for totals).
#'   - The sum of all values from column `"A"`, where `"A"` is any country,
#'     should match the total imports into country `"A"` reported in the
#'     commodity balance sheet (which is considered more accurate for totals).
#'
#'   The sums may not be exactly the expected values because of precision
#'   issues and/or the iterative proportional fitting algorithm not converging
#'   fast enough, but should be relatively very close to the desired totals.
#'
#'  The step by step approach to obtain this data tries to follow the FABIO
#'  model and is explained below. All the steps are performed separately for
#'  each group of year and item.
#'  - From the FAOSTAT reported bilateral trade, there are sometimes two values
#'    for one trade flow: the exported amount claimed by the reporter country
#'    and the import amount claimed by the partner country. Here, the export
#'    data was preferred, i.e., if country `"A"` says it exported `X` tonnes to
#'    country `"B"` but country `"B"` claims they got `Y` tonnes from country
#'    `"A"`, we trust the export data `X`. This choice is only needed if there
#'    exists a reported amount from both sides. Otherwise, the single existing
#'    report is chosen.
#'  - Complete the country data, that is, add any missing combinations of
#'    country trade with NAs, which will be estimated later. In the matrix
#'    form, this doesn't increase the memory usage since we had to build a
#'    matrix anyway (for the balancing algorithm), and the _empty_ parts also
#'    take up memory. This is also done for total imports/exports from the
#'    commodity balance sheet, but these are directly filled with 0s instead.
#'  - The total imports and exports from the commodity balance sheet are
#'    balanced by downscaling the largest of the two to match the lowest.
#'    This is done in the following way:
#'    - If `total_imports > total_exports`: Set `import` as
#'      `total_exports * import / total_import`.
#'    - If `total_exports > total_exports`: Set `export` as
#'      `total_exports * export / total_export`.
#'  - The missing data in the matrix must be estimated. It's done like this:
#'    - For each pair of exporter `i` and importer `j`, we estimate a bilateral
#'      trade `m[i, j]` using the export shares of `i` and import shares of `j`
#'      from the commodity balance sheet:
#'        - `est_1 <- exports[i] * imports[j] / sum(imports)`, i.e., total
#'          exports of country `i` spread among other countries' import shares.
#'        - `est_2 <- imports[j] * exports[i] / sum(exports)`, i.e. total
#'          imports of country `j` spread among other countries' export shares.
#'        - `est <- (est_1 + est_2) / 2`, i.e., the mean of both estimates.
#'
#'      In the above computations, exports and imports are the original values
#'      before they were balanced.
#'    - The estimates for data that already existed (i.e. non-NA) are discarded.
#'      For the ones left, for each row (i.e. exporter country), we get the
#'      difference between its balanced total export and the sum of original
#'      non-estimated data. The result is the _`gap`_ we can actually fill with
#'      estimates, so as to not get past the reported total export. If the sum
#'      of non-discarded estimates is larger, it must be downscaled and spread
#'      by computing
#'      `gap * non_discarded_estimate / sum(non_discarded_estimates)`.
#'    - The estimates are divided by a _trust factor_, in the sense that we
#'      don't rely on the whole value, thinking that a non-present value might
#'      actually be because that specific trade was 0, so we don't overestimate
#'      too much. The chosen factor is 10%, so only 10% of the estimate's value
#'      is actually used to fill the NA from the original bilateral trade
#'      matrix.
#'  - The matrix is balanced, as mentioned before, using the
#'    [iterative proportional fitting algorithm](
#'      https://en.wikipedia.org/wiki/Iterative_proportional_fitting
#'    ). The target sums for rows and columns are respectively the balanced
#'    exports and imports computed from the commodity balance sheet.
#'
#' @export
#'
#' @examples
#' get_bilateral_trade(example = TRUE)
get_bilateral_trade <- function(example = FALSE, cbs = NULL) {
  if (example) {
    return(.example_get_bilateral_trade())
  }

  if (is.null(cbs)) {
    cbs <- get_wide_cbs()
  }
  cbs <- cbs |>
    dplyr::select(year, item_cbs_code, area_code, export, import)

  cli::cli_progress_step("Reading raw bilateral trade data")
  btd <- "bilateral_trade" |>
    whep_read_file() |>
    .clean_bilateral_trade()

  codes <- .get_all_country_codes(btd, cbs)

  cli::cli_progress_step(
    "Balancing trade matrices ({nrow(btd)} year-item groups)"
  )
  btd |>
    .nest_by_year_item_code(cbs, codes) |>
    .process_bilateral_trade(codes) |>
    dplyr::select(-total_trade)
}

.process_bilateral_trade <- function(btd, codes) {
  n <- length(codes)
  code_int <- as.integer(levels(codes))
  ngroups <- nrow(btd)
  # mclapply() forks, which is unavailable on Windows; run serially there.
  # Same OS guard as spatialize.R. Output is identical on all platforms.
  n_cores <- if (.Platform$OS.type == "windows") {
    1L
  } else {
    max(1L, parallel::detectCores() %/% 2L)
  }

  btd$bilateral_trade <- parallel::mclapply(
    seq_len(ngroups),
    function(i) {
      btd$bilateral_trade[[i]] |>
        .build_trade_matrix(n, code_int) |>
        .fill_missing_trade(btd$total_trade[[i]]) |>
        .balance_matrix(btd$total_trade[[i]])
    },
    mc.cores = n_cores
  )
  btd
}

.balance_matrix <- function(trade_matrix, total_trade) {
  targets <- .trade_targets(total_trade, trade_matrix)
  exports <- targets$balanced_export
  imports <- targets$balanced_import
  n <- length(exports)

  if (sum(exports) == 0 && sum(imports) == 0) {
    return(matrix(0, nrow = n, ncol = n))
  }

  # Only run IPF on active countries to reduce matrix size.
  # Inactive countries (0 export and 0 import) would be
  # forced to 0 by IPF anyway, so excluding them gives the
  # same result with much less computation.
  active <- which(exports > 0 | imports > 0)
  sub <- trade_matrix[active, active, drop = FALSE]
  sub[sub == 0] <- 1
  # RAS/IPF scales multiplicatively, so a cell that is genuinely 0 going in
  # stays 0 through every iteration; but the seeding line above treats the
  # diagonal (self-trade, always 0) like any other unobserved zero, which
  # would let IPF allocate a spurious i -> i flow to hit the row/column
  # totals. Re-zero it so self-trade can never re-enter the balanced matrix.
  sub <- .zero_diagonal(sub)
  sub <- .ipf_2d(sub, exports[active], imports[active])

  result <- matrix(
    0,
    nrow = n,
    ncol = n,
    dimnames = dimnames(trade_matrix)
  )
  result[active, active] <- sub
  result
}

.balance_total_trade <- function(total_trade) {
  total_trade |>
    dplyr::mutate(
      total_export = sum(export),
      total_import = sum(import),
      balanced_export = ifelse(
        total_export > total_import,
        total_import * export / total_export,
        export
      ),
      balanced_import = ifelse(
        total_import > total_export,
        total_export * import / total_import,
        import
      )
    )
}

.clean_bilateral_trade <- function(btd) {
  btd <- dplyr::rename_with(btd, tolower)
  btd$unit[btd$unit == "Head"] <- "heads"
  is_export <- btd$element == "Export"
  from <- btd$area_code_p
  from[is_export] <- btd$area_code[is_export]
  to <- btd$area_code
  to[is_export] <- btd$area_code_p[is_export]
  btd$from_code <- as.integer(from)
  btd$to_code <- as.integer(to)
  btd$year <- as.integer(btd$year)

  items <- .get_cbs_items("item", "item_cbs_code")
  btd$item_cbs_code <- items$item_cbs_code[match(btd$item, items$item)]

  btd <- .prefer_flow_direction(btd, "Export")
  btd[c("year", "from_code", "to_code", "item_cbs_code", "unit", "value")]
}

# Keep all rows with preferred direction (Import, Export)
# when both of them exist. Otherwise use the one present.
.prefer_flow_direction <- function(bilateral_trade, direction) {
  is_preferred <- bilateral_trade$element == direction
  key <- bilateral_trade$from_code +
    bilateral_trade$to_code * 1e3 +
    bilateral_trade$year * 1e6 +
    bilateral_trade$item_cbs_code * 1e10
  has_preferred <- key %in% key[is_preferred]
  bilateral_trade[is_preferred | !has_preferred, ]
}

.fill_missing_trade <- function(trade_matrix, total_trade) {
  targets <- .trade_targets(total_trade, trade_matrix)
  exports <- targets$export
  imports <- targets$import
  balanced_exports <- targets$balanced_export

  na_mask <- is.na(trade_matrix)
  estimate <- .estimate_bilateral_trade(exports, imports)
  estimate[!na_mask] <- 0

  balances <- balanced_exports -
    .rowSums(trade_matrix, nrow(trade_matrix), ncol(trade_matrix), na.rm = TRUE)
  balances <- pmax(balances, 0)

  estimate <- .downscale_estimate_matrix(estimate, balances)

  # According to FABIO, missing data may be because it's truly zero,
  # so only use a small ratio of the estimate just in case.
  # TODO: Adapt this to our needs
  k_trust_factor <- 0.1
  trade_matrix[na_mask] <- estimate[na_mask] * k_trust_factor
  # The diagonal (a country trading with itself) starts NA from
  # .build_trade_matrix() and would otherwise be filled by the estimate above,
  # like any other missing cell -- but self-trade is never a real flow.
  .zero_diagonal(trade_matrix)
}

# Force the diagonal of a country x country trade matrix to exactly 0. A
# country never trades with itself; used both after estimating missing trade
# (.fill_missing_trade()) and after IPF's zero-seeding step (.balance_matrix())
# so self-trade can never re-enter the matrix.
.zero_diagonal <- function(trade_matrix) {
  diag(trade_matrix) <- 0
  trade_matrix
}

.trade_targets <- function(total_trade, trade_matrix) {
  use_names <- rlang::has_name(total_trade, "area_code") &&
    !is.null(rownames(trade_matrix)) &&
    !is.null(colnames(trade_matrix))

  if (!use_names) {
    return(list(
      export = total_trade$export,
      import = total_trade$import,
      balanced_export = total_trade$balanced_export,
      balanced_import = total_trade$balanced_import
    ))
  }

  area_codes <- as.character(total_trade$area_code)
  row_idx <- match(rownames(trade_matrix), area_codes)
  col_idx <- match(colnames(trade_matrix), area_codes)

  list(
    export = .target_by_index(total_trade$export, row_idx),
    import = .target_by_index(total_trade$import, col_idx),
    balanced_export = .target_by_index(
      total_trade$balanced_export,
      row_idx
    ),
    balanced_import = .target_by_index(
      total_trade$balanced_import,
      col_idx
    )
  )
}

.target_by_index <- function(values, idx) {
  result <- rep(0, length(idx))
  valid <- !is.na(idx)
  result[valid] <- values[idx[valid]]
  result[is.na(result)] <- 0
  result
}

.downscale_estimate_matrix <- function(needed_estimates, balances) {
  nr <- nrow(needed_estimates)
  nc <- ncol(needed_estimates)
  row_sums <- .rowSums(needed_estimates, nr, nc, na.rm = TRUE)
  scale <- rep.int(1, nr)
  needs_scale <- row_sums > 0 & row_sums > balances
  scale[needs_scale] <- balances[needs_scale] / row_sums[needs_scale]
  needed_estimates * scale
}

.nest_by_year_item_code <- function(btd, cbs, codes) {
  cbs <- cbs |>
    dplyr::mutate(area_code = factor(area_code, levels = codes))

  btd |>
    dplyr::filter(unit %in% c("tonnes", "heads")) |>
    dplyr::select(-unit) |>
    .filter_only_items_in_cbs(cbs) |>
    tidyr::nest(
      bilateral_trade = c(from_code, to_code, value),
      .by = c(year, item_cbs_code)
    ) |>
    dplyr::inner_join(.get_nested_cbs(cbs, codes), c("year", "item_cbs_code"))
}

.get_nested_cbs <- function(cbs, codes) {
  cbs |>
    .complete_total_trade(codes) |>
    dplyr::group_by(year, item_cbs_code) |>
    .balance_total_trade() |>
    dplyr::ungroup() |>
    tidyr::nest(
      total_trade = c(
        area_code,
        export,
        import,
        balanced_export,
        balanced_import
      ),
      .by = c(year, item_cbs_code)
    )
}

.complete_total_trade <- function(total_trade, codes) {
  df_codes <- tibble::tibble(area_code = codes)
  combs <- total_trade |>
    dplyr::distinct(year, item_cbs_code) |>
    dplyr::cross_join(df_codes)

  total_trade |>
    dplyr::right_join(combs, by = c("year", "item_cbs_code", "area_code")) |>
    tidyr::replace_na(list(export = 0, import = 0))
}

.filter_only_items_in_cbs <- function(btd, cbs) {
  btd_items <- btd |>
    dplyr::pull(item_cbs_code) |>
    unique() |>
    sort()

  cbs_items <- cbs |>
    dplyr::pull(item_cbs_code) |>
    unique() |>
    sort()

  # TODO: Also include these (need total export/import reports)
  items_not_in_cbs <- btd_items[!btd_items %in% cbs_items]

  btd |>
    dplyr::filter(!item_cbs_code %in% items_not_in_cbs)
}

.get_all_country_codes <- function(btd, cbs) {
  c(
    dplyr::pull(btd, from_code),
    dplyr::pull(btd, to_code),
    dplyr::pull(cbs, area_code)
  ) |>
    unique() |>
    sort() |>
    as.factor()
}

.build_trade_matrix <- function(btd, n, code_int) {
  code_levels <- as.character(code_int)
  m <- matrix(
    NA_real_,
    nrow = n,
    ncol = n,
    dimnames = list(code_levels, code_levels)
  )
  btd <- btd |>
    dplyr::summarise(
      value = sum(.data$value, na.rm = TRUE),
      .by = c("from_code", "to_code")
    )
  rows <- match(btd$from_code, code_int)
  cols <- match(btd$to_code, code_int)
  m[cbind(rows, cols)] <- btd$value
  m
}

.estimate_bilateral_trade <- function(exports, imports) {
  sum_exp <- sum(exports)
  sum_imp <- sum(imports)
  if (sum_exp == 0 || sum_imp == 0) {
    return(matrix(0, nrow = length(exports), ncol = length(imports)))
  }
  scale <- (1 / sum_imp + 1 / sum_exp) / 2
  tcrossprod(exports, imports * scale)
}

# Iterative proportional fitting of the bilateral trade matrix. This
# is RAS / biproportional fitting and delegates to the shared core in
# balance.R; trade matrices are small and dense, so they take the
# dense scaling path. Returns the best estimate even if not converged.
.ipf_2d <- function(
  seed,
  target_rows,
  target_cols,
  max_iter = 1000L,
  tol = 0.1
) {
  .ras_iterate(seed, target_rows, target_cols, max_iter, tol)$m
}
