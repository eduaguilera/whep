#' Manure nitrogen application by crop and country
#'
#' @description
#' Country- and crop-level estimates of manure nitrogen applied to cropland,
#' from West et al. (2014). Used as a reference for spatializing manure N
#' inputs in the WHEP pipeline.
#'
#' @format
#' A tibble with one row per crop-country combination containing:
#' - `Crop_name`: Crop name (character).
#' - `ISO`: ISO 3166-1 alpha-3 country code.
#' - `Continent`: Three-letter continent code (e.g. `"AFR"`, `"ASI"`).
#' - `Manure_N_Mg`: Manure nitrogen applied in megagrams (Mg).
#'
#' @source West, P. C. et al. (2014). Leverage points for improving global
#'   food security and the environment. *Science*, 345(6194), 325–328.
#'   \doi{10.1126/science.1246067}
#'
#' @examples
#' head(crops_manure_n)
"crops_manure_n"

#' Grassland share of synthetic nitrogen by country and year
#'
#' @description
#' Country-level time series of the share of synthetic nitrogen applied to
#' grassland (versus cropland). Used to split national N totals between land
#' use types in the WHEP nitrogen pipeline.
#'
#' @format
#' A tibble with one row per country-year combination containing:
#' - `Country`: Country name.
#' - `year`: Year (numeric).
#' - `grass_share`: Share of synthetic N applied to grassland (0–1).
#'
#' @source Lassaletta et al. nitrogen flow dataset. See pipeline
#'   documentation for full citation.
#'
#' @examples
#' head(lassaletta_grassland_share)
"lassaletta_grassland_share"

#' Smil (2001) global synthetic nitrogen production, 1913-2000
#'
#' @description
#' Global synthetic-nitrogen production anchors from Smil (2001)
#' "Enriching the Earth", Tables 5.2 and 5.3, cross-checked with
#' Smil (2002) Ambio 31:126-131. Anchor years span 1913 (first
#' commercial Haber-Bosch plant at BASF Oppau) to 2000. Used by
#' `prepare_nitrogen_inputs()` to backcast country-level synthetic N
#' for the pre-FAOSTAT period (years before 1961): the temporal shape
#' is taken from this global series and downscaled to each country
#' using its 1961-1965 share of global FAOSTAT synthetic N.
#'
#' Pre-1913 values are treated as zero by the consumer and are not
#' stored here.
#'
#' @format A tibble with one row per anchor year:
#' - `year`: Integer anchor year (1913, 1920, 1925, ..., 2000).
#' - `global_kt_n`: Global synthetic-N production in kt N.
#'
#' @source Smil, V. (2001) *Enriching the Earth: Fritz Haber, Carl
#'   Bosch, and the Transformation of World Food Production*, MIT
#'   Press. Tables 5.2 and 5.3.
#'
#' @examples
#' head(smil_2001_synthetic_n_global)
"smil_2001_synthetic_n_global"

#' Synthetic nitrogen application rates by crop and country
#'
#' @description
#' Country- and crop-process-level synthetic nitrogen application rates
#' (kg N ha\eqn{^{-1}}), derived from Mueller et al. (2012). Used as
#' reference crop-specific N rates in the WHEP nitrogen pipeline.
#'
#' @format
#' A tibble with one row per crop-process-country combination containing:
#' - `proc_code`: Internal process code (e.g. `"p001"`).
#' - `crop_process`: Descriptive crop process name (e.g. `"Rice production"`).
#' - `crop_original`: Crop name as in the source dataset.
#' - `unit`: Unit of the rate value (always `"kgN/ha"`).
#' - `iso3c`: ISO 3166-1 alpha-3 country code.
#' - `rate_value`: Nitrogen application rate (kg N ha\eqn{^{-1}}).
#'
#' @source Mueller, N. D. et al. (2012). Closing yield gaps through nutrient
#'   and water management. *Nature*, 490(7419), 254–257.
#'   \doi{10.1038/nature11420}
#'
#' @examples
#' head(mueller_synthetic_n)
"mueller_synthetic_n"

#' Animal codes and classifications
#'
#' Maps live animal CBS items to their livestock classifications, process codes,
#' and associated product items used in livestock modeling.
#'
#' @format
#' A tibble where each row corresponds to one live animal CBS item.
#' It contains the following columns:
#' - `Item_Code`: Numeric FAOSTAT item code for the live animal.
#' - `item_cbs`: Name of the CBS item (e.g., `"Cattle"`, `"Asses"`).
#' - `proc_code`: Short process code used internally (e.g., `"p092"`).
#' - `proc`: Descriptive process name (e.g., `"Asses"`).
#' - `item_cbs_code`: Numeric CBS item code (often equal to `Item_Code`).
#' - `Farm_class`: Broad farm classification grouping the animal. One of
#'   `"Cattle"`, `"Dairy_cows"`, `"Monogastric"`, `"Sheep_goats"`,
#'   `"Bees"`, `"Game"`.
#' - `Item_product`: Name of the primary product derived from this animal, if
#'   applicable (e.g., milk for dairy cows).
#' - `Item_Code_product`: Numeric FAOSTAT code for the associated product item.
#' - `Liv_prod_cat`: Livestock product category the animal belongs to.
#' - `Graniv_grazers`: Broad feeding behaviour classification. One of
#'   `"Grazers"`, `"Granivores"`, `"Bees"`, `"Game"`.
#' - `Livestock_name`: Internal livestock identifier used across datasets
#'   (e.g., `"Cattle"`, `"Dairy_cows"`, `"Asses"`).
#' - `Animal_class`: Fine-grained animal class, including production type
#'   distinctions (e.g., `"Broilers"`, `"Hens"`, `"Hogs"`, `"Dairy_cows"`).
#' - `Item_FAOmanure`: Name of the corresponding FAOSTAT manure management item.
#' - `Item_Code_FAOmanure`: Numeric code of the FAOSTAT manure management item.
#' - `Cat_Labour`: Labour category used in labour-related analyses. One of
#'   `"Cattle"`, `"Equines"`, `"Dairy_cows"`, `"Birds"`,
#'   `"Small_ruminants"`, `"Pigs"`, `"Bees"`.
#' - `Cat_FAO1`: Top-level FAO category. Currently always `"Animal"`.
#' - `item_bouwman`: Item name used in Bouwman et al. livestock datasets.
#' @source Derived from [FAOSTAT data](https://www.fao.org/faostat/en/#data/QA)
#'   and internal livestock classification work.
#'
#' @examples
#' head(animals_codes)
"animals_codes"

#' Biomass coefficients for crops and livestock products
#'
#' Provides dry-matter, nutrient, and energy conversion coefficients for
#' agricultural products and residues. Used to convert fresh-matter production
#' quantities into biomass flows, nutrient budgets, and energy content.
#'
#' @format
#' A tibble where each row corresponds to one product or item. It contains
#' 68 columns:
#' - `Code`: Item code (character), corresponding to FAOSTAT production codes.
#' - `Name_biomass`: Item name as used in biomass accounting.
#' - `Equiv`: Reference equivalence item used when coefficients are borrowed
#'   from another similar commodity (e.g., `"Wheat"` for oats).
#' - `Category`: Broad commodity category (e.g., `"Cereals, other"`,
#'   `"Barley"`, `"Vegetables"`).
#' - `BG_Biomass_kgDM_ha`: Below-ground biomass in kg dry matter per hectare.
#' - `Root_Shoot_ratio`: Ratio of root to aerial biomass (dimensionless).
#' - `Product_kgDM_kgFM`: Product dry-matter content in kg DM per kg fresh
#'   matter.
#' - `Residue_kgDM_kgFM`: Residue dry-matter content in kg DM per kg fresh
#'   matter of product.
#' - `Conventional_kgDM_ha`: Conventional yield in kg dry matter per hectare.
#' - `Organic_kgDM_ha`: Organic yield in kg dry matter per hectare.
#' - `GE_product_edible_portion_MJ_kgFM`: Gross energy of the edible portion
#'   in MJ per kg fresh matter.
#' - `GE_product_residue_MJ_kgFM`: Gross energy of the residue in MJ per kg
#'   fresh matter (may be character due to source formatting).
#' - `GE_product_MJ_kgFM`: Gross energy of the whole product in MJ per kg
#'   fresh matter.
#' - `GE_residue_MJ_kg`: Gross energy of the residue in MJ per kg.
#' - `kg_product_kg_aerial_biomass`: Fraction of aerial biomass that is
#'   product (harvest index, kg/kg).
#' - `kg_residue_kg_aerial_biomass_FM`: Fraction of aerial biomass that is
#'   residue, on fresh matter basis.
#' - `kg_residue_kg_product_FM`: Ratio of residue to product on fresh matter
#'   basis.
#' - `Carcass_to_LW`: Carcass-to-live-weight ratio (livestock only; logical
#'   placeholder for crop items).
#' - `Edible_portion`: Edible fraction of the product (kg edible / kg fresh
#'   matter).
#' - `N_kgN_kgFM`: Nitrogen content in kg N per kg fresh matter.
#' - `Lipids_g_kgFM`: Lipid content in g per kg fresh matter.
#' - `Carbohydrates_g_kgFM`: Carbohydrate content in g per kg fresh matter.
#' - `Calcium_mg_kgFM`: Calcium content in mg per kg fresh matter.
#' - `VitaminA_microg_kgFM`: Vitamin A content in micrograms per kg fresh
#'   matter.
#' - `Edible_kgDM_kgFM`: Edible dry matter in kg per kg fresh matter.
#' - `Edible_kgC_kgFM`: Edible carbon in kg C per kg fresh matter.
#' - `Edible_N_kgFM`: Edible nitrogen in kg N per kg fresh matter.
#' - `Edible_kgP_kgFM`: Edible phosphorus in kg P per kg fresh matter.
#' - `Edible_K_kgFM`: Edible potassium in kg K per kg fresh matter.
#' - `NonEdible_kgDM_kgFM`: Non-edible dry matter in kg per kg fresh matter.
#' - `NonEdible_kgC_kgFM`: Non-edible carbon in kg C per kg fresh matter.
#' - `NonEdible_kgN_kgFM`: Non-edible nitrogen in kg N per kg fresh matter.
#' - `NonEdible_kgP_kgFM`: Non-edible phosphorus in kg P per kg fresh matter.
#' - `NonEdible_kgK_kgFM`: Non-edible potassium in kg K per kg fresh matter.
#' - `Product_kgN_kgDM`: Nitrogen content of product in kg N per kg dry
#'   matter.
#' - `Product_kgP_kgDM`: Phosphorus content of product in kg P per kg dry
#'   matter.
#' - `Product_kgK_kgDM`: Potassium content of product in kg K per kg dry
#'   matter.
#' - `Product_kgC_kgDM`: Carbon content of product in kg C per kg dry matter.
#' - `Residue_kgN_kgDM`: Nitrogen content of residue in kg N per kg dry
#'   matter.
#' - `Residue_kgP_kgDM`: Phosphorus content of residue in kg P per kg dry
#'   matter.
#' - `Residue_kgK_kgDM`: Potassium content of residue in kg K per kg dry
#'   matter.
#' - `Residue_kgC_kgDM`: Carbon content of residue in kg C per kg dry matter.
#' - `Residue_humified_kgC_kgC`: Humification coefficient of residue carbon
#'   (fraction of residue C stabilised as soil organic matter).
#' - `MgDM_m3`: Megagrams dry matter per cubic metre (bulk density proxy).
#' - `Root_kgC_kgDM`: Root plus rhizodeposit carbon in kg C per kg root dry
#'   matter.
#' - `Root_humified_kgC_kgC`: Humification coefficient for root carbon.
#' - `Root_mass_kgC_kgDM`: Root carbon mass in kg C per kg crop dry matter.
#' - `Rhizodeposits_mass_kgC_kgDM`: Rhizodeposit carbon in kg C per kg crop
#'   dry matter.
#' - `Residue_C_N`: Carbon-to-nitrogen ratio of the residue.
#' - `Root_kgN_kgDM`: Nitrogen content of roots in kg N per kg root dry
#'   matter.
#' - `GE_Roots_MJ_kgDM`: Gross energy of roots in MJ per kg dry matter.
#' - `Rhizodeposits_N_kgN_kgRootN`: Rhizodeposit nitrogen as a fraction of
#'   root nitrogen.
#' - `Fiber_g_kgFM`: Dietary fibre content in g per kg fresh matter.
#' - `SFA_g_kgFM`: Saturated fatty acid content in g per kg fresh matter.
#' - `MUFA_g_kgFM`: Monounsaturated fatty acid content in g per kg fresh
#'   matter.
#' - `PUFA_g_kgFM`: Polyunsaturated fatty acid content in g per kg fresh
#'   matter.
#' - `PUFA_n3_g_kgFM`: Omega-3 PUFA content in g per kg fresh matter.
#' - `Iron_mg_kgFM`: Iron content in mg per kg fresh matter.
#' - `Zinc_mg_kgFM`: Zinc content in mg per kg fresh matter.
#' - `Magnesium_mg_kgFM`: Magnesium content in mg per kg fresh matter.
#' - `Cadmium_microg_kgFM`: Cadmium content in micrograms per kg fresh matter.
#' - `VitaminB12_microg_kgFM`: Vitamin B12 content in micrograms per kg fresh
#'   matter.
#' - `VitaminD_microg_kgFM`: Vitamin D content in micrograms per kg fresh
#'   matter.
#' - `Folate_microg_kgFM`: Folate content in micrograms per kg fresh matter.
#' - `VitaminC_mg_kgFM`: Vitamin C content in mg per kg fresh matter.
#' - `VitaminE_mg_kgFM`: Vitamin E content in mg per kg fresh matter.
#' - `Flavonoids_mg_kgFM`: Flavonoid content in mg per kg fresh matter.
#' - `Carotenoids_mg_kgFM`: Carotenoid content in mg per kg fresh matter.
#' @source Compiled from multiple sources including FAO food composition data,
#'   crop physiology literature, and IPCC Tier 1 coefficients.
#'
#' @examples
#' head(biomass_coefs)
"biomass_coefs"

#' FAOSTAT crop to LPJmL crop functional type (CFT) mapping
#'
#' Maps FAOSTAT primary-production item codes to WHEP's granular
#' 33-class crop functional type taxonomy and the coarser
#' LPJmL-compatible parent class. Used by
#' [build_gridded_landuse()] and [run_spatialize()] to aggregate
#' spatialized crop-level output into named crop functional types.
#'
#' @format
#' A tibble with one row per mapped FAOSTAT item. Columns:
#' - `item_prod_code`: Integer FAOSTAT item code.
#' - `item_prod_name`: Human-readable FAOSTAT item name.
#' - `cft_name`: Granular WHEP CFT name (33 classes, e.g.
#'   `"temperate_cereals"`, `"coffee"`, `"oil_crops_oilpalm"`).
#' - `cft_lpjml`: LPJmL-compatible parent class; one of the 12
#'   LPJmL v6 named crop CFTs or `"others"`.
#' - `luh2_type`: LUH2 crop functional type (`c3ann`, `c4ann`,
#'   `c3per`, or `c3nfx`).
#' @source Adapted from LandInG's
#'   `crop_types_FAOSTAT_LPJmL_default.csv` (Ostberg et al. 2023)
#'   with WHEP granular extensions.
#'
#' @examples
#' head(cft_mapping)
"cft_mapping"

#' Commodity balance sheet processing fractions
#'
#' Specifies the product fractions obtained when CBS items are processed,
#' linking processed items to their output CBS categories.
#'
#' @format
#' A tibble where each row corresponds to one processed-item / output-category
#' combination. It contains the following columns:
#' - `ProcessedItem`: Name of the CBS item being processed (e.g.,
#'   `"Apples and products"`, `"Barley and products"`).
#' - `item_cbs`: Name of the output CBS category produced by processing (e.g.,
#'   `"Alcohol, Non-Food"`).
#' - `Product_fraction`: Conversion factor from processed input quantity to
#'   output product quantity. This can exceed 1 when the output includes added
#'   mass, such as water in beverages.
#' - `Value_fraction`: Economic value fraction associated with the output
#'   product (numeric; largely `NA` in current data).
#' - `Required`: Marks required co-product links in selected processing
#'   chains.
#' @source Derived from FAOSTAT commodity balance sheet processing assumptions.
#'
#' @examples
#' head(cb_processing)
"cb_processing"

#' CBS to trade item code mapping
#'
#' Maps detailed FAOSTAT trade item codes to their corresponding CBS item
#' categories, enabling aggregation of bilateral trade data into the CBS
#' framework.
#'
#' @format
#' A tibble where each row corresponds to one trade item. It contains the
#' following columns:
#' - `item_code_trade`: Numeric FAOSTAT trade item code (e.g., `15` for
#'   wheat).
#' - `item_trade`: Name of the trade item (e.g., `"Wheat"`,
#'   `"Flour, wheat"`, `"Bran, wheat"`).
#' - `item_cbs`: Name of the CBS category this trade item belongs to (e.g.,
#'   `"Wheat and products"`).
#' - `item_check`: Cross-validation column repeating the mapped CBS name;
#'   used to flag mapping inconsistencies during data processing.
#' @source Derived from [FAOSTAT Detailed Trade Matrix](https://www.fao.org/faostat/en/#data/TM)
#'   and commodity balance sheet correspondence tables.
#'
#' @examples
#' head(cbs_trade_codes)
"cbs_trade_codes"

#' Eurostat crop classification codes
#'
#' Maps Eurostat crop codes to their full crop category names, used when
#' integrating Eurostat agricultural statistics.
#'
#' @format
#' A tibble where each row corresponds to one Eurostat crop category.
#' It contains the following columns:
#' - `Crop`: Eurostat crop code (e.g., `"G0000"`, `"G1000"`).
#' - `Name_Eurostat`: Full name of the crop category as used in Eurostat
#'   (e.g., `"Plants harvested green from arable land"`,
#'   `"Temporary grasses and grazings"`).
#' @source [Eurostat Agricultural Statistics](https://ec.europa.eu/eurostat/statistics-explained/index.php/Agricultural_statistics).
#'
#' @examples
#' head(crops_eurostat)
"crops_eurostat"

#' Full CBS item table
#'
#' Extended item reference table covering all CBS items, including their
#' process and commodity codes, feed type classifications, and default
#' material flow destinations.
#'
#' @format
#' A tibble where each row corresponds to one CBS item. It contains the
#' following columns:
#' - `item_cbs`: Name of the CBS item.
#' - `item_cbs_code`: Numeric CBS item code.
#' - `comm_code`: Commodity code used in process-based modelling (may contain
#'   `"#N/A"` when not applicable).
#' - `proc_code`: Process code (may contain `"#N/A"` when not applicable).
#' - `proc`: Process name (may contain `"#N/A"` when not applicable).
#' - `unit`: Measurement unit (typically `"tonnes"`).
#' - `group`: Broad item group. Common values include `"Additives"`,
#'   `"Crop products"`, `"Crop residues"`, `"Draught"`, `"Fish"`,
#'   `"Forestry"`, `"Grass"`, `"Livestock"`, and others.
#' - `feedtype_graniv`: Feed type classification for granivores
#'   (e.g., `"additives"`, `"concentrates"`, `"roughages"`).
#' - `feedtype_grazers`: Feed type classification for grazers.
#' - `comm_group`: Sub-group of the commodity (e.g., `"Additives"`,
#'   `"Alcohol"`, `"Ethanol"`, `"Oil cakes"`,
#'   `"Other processing residues"`).
#' - `Cat_1`: Primary category label used in material flow accounting.
#' - `Name_biomass`: Corresponding item name in `biomass_coefs`, enabling
#'   joins with the biomass coefficient table.
#' - `dbMFA_items`: Item identifier used in the material flow analysis
#'   database.
#' - `FEDNA`: Item name used in FEDNA feed composition tables.
#' - `default_destiny`: Default CBS use category for this item. One of
#'   `"Feed"`, `"Food"`, `"Other_uses"`, `"Processing"`, or `NA`.
#' @source Derived from [FAOSTAT data](https://www.fao.org/faostat/en/#data/FBS)
#'   and internal commodity classification work.
#'
#' @examples
#' head(items_full)
"items_full"

#' Primary production items linked to CBS
#'
#' Maps FAOSTAT primary production items and crop products to their CBS
#' counterparts, along with farm and labour classifications.
#'
#' @format
#' A tibble where each row corresponds to one production item. It contains
#' the following columns:
#' - `item_prod`: Name of the production item (e.g., `"Wheat"`, `"Rice"`).
#' - `item_prod_code`: FAOSTAT production item code (character).
#' - `item_cbs`: Name of the corresponding CBS item.
#' - `item_cbs_code`: Numeric CBS item code.
#' - `Farm_class`: Farm system classification. Crop items use codes such as
#'   `"COP"` (cereals, oilseeds, protein crops), `"Vegetables"`,
#'   `"Fruits"`, `"Olive"`, `"Grapevine"`, `"Other_crops"`. Livestock
#'   items use `"Dairy_cows"`, `"Cattle"`, `"Monogastric"`,
#'   `"Sheep_goats"`, `"Bees"`, `"Game"`. `NA` for non-farm items.
#' - `Cat_Labour`: Labour category used in agricultural labour analyses.
#' - `Cat_FAO1`: Top-level FAO commodity category.
#' - `group`: Item group classification. One of `"Primary crops"`,
#'   `"Crop products"`, `"Livestock products"`, `"Grass"`,
#'   `"Crop residues"`, `"Scavenging"`, `"Livestock"`.
#' @source Derived from [FAOSTAT Production data](https://www.fao.org/faostat/en/#data/QCL).
#'
#' @examples
#' head(items_prim)
"items_prim"

#' Full production item table
#'
#' Comprehensive reference table for all production items, combining CBS
#' linkages, biomass names, multiple classification schemes, and crop
#' ecological traits.
#'
#' @format
#' A tibble where each row corresponds to one production item. It contains
#' the following columns:
#' - `item_prod`: Name of the production item.
#' - `item_prod_code`: FAOSTAT production item code (character).
#' - `item_cbs`: Name of the corresponding CBS item.
#' - `item_cbs_code`: Numeric CBS item code.
#' - `group`: Item group. One of `"Primary crops"`, `"Crop products"`,
#'   `"Livestock products"`, `"Crop residues"`, `"Grassland"`,
#'   `"Scavenging"`.
#' - `live_anim`: Name of the parent live animal for livestock-derived items
#'   (`NA` for crop items).
#' - `live_anim_code`: Numeric CBS code of the parent live animal (`NA` for
#'   crop items).
#' - `Cat_Krausmann`: Item category used in Krausmann et al. biomass flow
#'   accounting.
#' - `Name_biomass`: Corresponding item name in `biomass_coefs`, enabling
#'   joins for biomass coefficients.
#' - `Name_Eurostat`: Corresponding item name in Eurostat agricultural
#'   statistics.
#' - `Name`: Alternative or display name for the item.
#' - `Cat_Labour`: Labour category used in agricultural labour analyses.
#' - `Cat_FAO1`: Top-level FAO commodity category (e.g., `"Cereals"`,
#'   `"Oilcrops"`).
#' - `Cat_Origin`: Origin-based commodity category. One of `"Cereals"`,
#'   `"Vegetables and Fruits"`, `"Sugar and Stimulants"`, `"Oil Crops"`,
#'   `"Fodder crops"`, `"Fibres and Crude Materials"`, or `NA`.
#' - `Cat_Use`: Use-based commodity category (e.g., `"Grains"`,
#'   `"Oils and Fats"`, `"Fodder crops"`, `"Beverages, sugar and
#'   stimulants"`).
#' - `Order`: Numeric ordering field used for sorting items consistently
#'   across outputs.
#' - `Categ`: General category label used in some analyses.
#' - `Farm_class`: Farm system classification (see `items_prim` for values).
#' - `c3_c4`: Photosynthetic pathway. One of `"c3"`, `"c4"`, or `NA`.
#' - `ann_per_nfx`: Annual/perennial and nitrogen fixation trait. One of
#'   `"ann"` (annual), `"per"` (perennial), `"nfx"` (nitrogen-fixing),
#'   or `NA`.
#' - `Cat_1`: Primary category label for material flow accounting.
#' - `Cat_2`: Secondary category label.
#' - `Cat_3`: Tertiary category label.
#' - `Cat_4`: Quaternary category label.
#' - `Herb_Woody`: Plant growth form. One of `"Herbaceous"`, `"Woody"`, or
#'   `NA`.
#' - `Crop_irrig`: Irrigation category used in water-use analyses.
#' - `Cat_Org`: Organic farming category classification.
#' - `Cat_Ymax`: Maximum attainable yield category.
#' - `Cat_Ymax_leg`: Legend label for the `Cat_Ymax` category.
#' @source Derived from [FAOSTAT Production data](https://www.fao.org/faostat/en/#data/QCL)
#'   and multiple classification schemes from the literature.
#'
#' @examples
#' head(items_prod_full)
"items_prod_full"

#' Livestock unit coefficients
#'
#' Provides livestock unit (LU) conversion factors per head for each animal
#' class, used to express heterogeneous livestock populations in comparable
#' units.
#'
#' @format
#' A tibble where each row corresponds to one animal class. It contains the
#' following columns:
#' - `Animal_class`: Animal class identifier (e.g., `"Dairy_cows"`,
#'   `"Cattle"`, `"Sheep_goats"`, `"Broilers"`, `"Hens"`, `"Pigs"`).
#' - `LU_head`: Livestock units per head (numeric). Dairy cows have a value
#'   of 1.0 by convention; smaller animals have proportionally lower values.
#' @source Based on standard livestock unit definitions from FAO and
#'   European agricultural statistics.
#'
#' @examples
#' head(liv_lu_coefs)
"liv_lu_coefs"

#' Polity categories and regional classifications
#'
#' Reference table for countries and political entities (polities) with
#' identifiers from multiple data sources and assignments to various regional
#' groupings used in the literature and international databases.
#'
#' @format
#' A tibble where each row corresponds to one polity (country or territory).
#' It contains the following columns:
#' - `polity_prefix`: Polity **family prefix**, usually ISO 3166-1 alpha-3
#'   (e.g., `"AFG"`, `"ALB"`). This is NOT a polity code and will not resolve
#'   against [polities]: a code identifies one period (`"AFG-1919-2025"`),
#'   whereas a prefix names the whole family. Use `reporting_polity_code` to
#'   join to [polities] or [polity_area_crosswalk]. Renamed from `polity_code`
#'   in 0.3.0.9000, where the misleading name invited exactly that bad join.
#' - `polity_name`: Current polity, country, or territory name.
#' - `V1`: Internal row index from the source table.
#' - `code`: Numeric FAOSTAT country code.
#' - `polity_area_code`: Numeric WHEP reporting area code used in matrix
#'   workflows.
#' - `reporting_polity_code`: Current periodized WHEP polity code for `code`.
#' - `reporting_polity_name`: Current WHEP polity name for `code`.
#' - `reporting_polity_has_geometry`: Logical flag indicating whether the
#'   current reporting polity has a polygon.
#' - `reporting_polity_continent`: Continent of the current reporting polity,
#'   taken from the polities database. Prefer this over the vendored
#'   `region_UN` column, which disagrees with it for 54 of 253 comparable
#'   areas and is internally inconsistent (the USSR is filed under Asia while
#'   its successor the Russian Federation is filed under Europe).
#' - `iso3c`: ISO 3166-1 alpha-3 code (character; may duplicate
#'   `polity_prefix` or differ for aggregates).
#' - `FAOSTAT_name`: Country name as used in FAOSTAT.
#' - `EU27`: Logical flag; `TRUE` if the polity is a member of the EU27.
#' - `name`: Country name used in other external databases.
#' - `eia`: Country name or code used by the US Energy Information
#'   Administration (EIA).
#' - `iea`: Country identifier used by the International Energy Agency (IEA).
#' - `water_code`: Numeric code used in water statistics datasets.
#' - `water_area`: Country/area name used in water statistics.
#' - `baci`: Numeric BACI trade database country code.
#' - `fish`: Numeric code used in fisheries datasets.
#' - `region_code`: Numeric regional grouping code.
#' - `cbs`: Logical flag; `TRUE` if the polity is included in the CBS
#'   dataset.
#' - `fabio_code`: Numeric country code used in the FABIO database.
#' - `ADB_Region`: Asian Development Bank regional classification.
#' - `region`: General world region (e.g., `"South Asia"`,
#'   `"Eastern Europe"`).
#' - `uISO3c`: Numeric Unicode / UN M49 country code.
#' - `Lassaletta`: Country grouping used in Lassaletta et al. nitrogen flow
#'   studies.
#' - `region_krausmann`: Regional grouping from Krausmann et al. biomass
#'   flow accounting.
#' - `region_HANPP`: Regional grouping used in human appropriation of net
#'   primary production (HANPP) studies.
#' - `region_krausmann2`: Alternative Krausmann regional grouping.
#' - `region_UN_sub`: UN sub-regional classification (M49 sub-region).
#' - `region_UN`: UN macro-regional classification (M49 region).
#' - `region_ILO1`: ILO primary regional grouping.
#' - `region_ILO2`: ILO secondary regional grouping.
#' - `region_ILO3`: ILO tertiary regional grouping.
#' - `region_IEA`: IEA regional grouping.
#' - `region_IPCC`: IPCC regional grouping used in climate assessments.
#' - `region_labour`: Labour-focused regional grouping.
#' - `region_labour_agg`: Aggregated labour-focused regional grouping.
#' - `region_labour_mech`: Labour mechanisation regional grouping.
#' - `region_test`: Experimental/test regional grouping (may be incomplete).
#' @source Compiled from [FAOSTAT](https://www.fao.org/faostat/), UN M49,
#'   ILO, IEA, and other international statistical sources.
#' @note Five trailing columns containing only Excel `#REF!` errors in the
#'   source CSV are dropped at load time and are not part of this dataset.
#'
#' @examples
#' head(polities_cats)
"polities_cats"

#' Items with double-counting in production statistics
#'
#' Identifies production items that appear both as primary crop products and
#' as harvested-area items, requiring special treatment to avoid
#' double-counting in production and biomass accounting.
#'
#' @format
#' A tibble where each row corresponds to one item pair with a
#' double-counting relationship. It contains the following columns:
#' - `Item_area`: Name of the item as it appears in harvested-area statistics
#'   (e.g., `"Seed cotton, unginned"`).
#' - `item_prod`: Name of the derived production item (e.g.,
#'   `"Cotton lint, ginned"`, `"Cotton seed"`).
#' - `item_prod_code`: Numeric FAOSTAT production code of the derived item.
#' - `Multi_type`: Classification of the double-counting type:
#'   - `"Primary"`: The area item is the primary crop; product is a direct
#'     output.
#'   - `"Primary_area"`: Area is recorded under a primary aggregate crop
#'     name.
#'   - `"Multi"`: Multiple products share the same harvested area.
#'   - `"Multi_area"`: Multiple products share a recorded area aggregate.
#' @source Derived from FAOSTAT production methodology documentation.
#'
#' @examples
#' head(primary_double)
"primary_double"

#' Full polity and region reference table
#'
#' Extended reference table covering all polities and aggregate regions,
#' including countries, territories, and statistical composites that appear
#' in international databases but may lack standard ISO codes.
#'
#' @format
#' A tibble where each row corresponds to one polity or aggregate region. It
#' contains the following columns (same definitions as `polities_cats`,
#' minus the five trailing `0...36`–`0...40` artefact columns):
#' - `polity_prefix`: Polity **family prefix** (ISO3-like), not a polity code;
#'   see `regions_full` for why the two must not be confused. Join to
#'   [polities] via `reporting_polity_code`. Renamed from `polity_code` in
#'   0.3.0.9000.
#' - `polity_name`: Current polity, country, territory, or aggregate name.
#' - `V1`: Internal row index.
#' - `code`: Numeric FAOSTAT country/region code.
#' - `polity_area_code`: Numeric WHEP reporting area code used in matrix
#'   workflows.
#' - `reporting_polity_code`: Current periodized WHEP polity code for `code`.
#' - `reporting_polity_name`: Current WHEP polity name for `code`.
#' - `reporting_polity_has_geometry`: Logical flag indicating whether the
#'   current reporting polity has a polygon.
#' - `reporting_polity_continent`: Continent of the current reporting polity,
#'   taken from the polities database. Prefer this over the vendored
#'   `region_UN` column, which disagrees with it for 54 of 253 comparable
#'   areas and is internally inconsistent (the USSR is filed under Asia while
#'   its successor the Russian Federation is filed under Europe).
#' - `iso3c`: ISO 3166-1 alpha-3 code (`NA` for aggregates).
#' - `FAOSTAT_name`: Name used in FAOSTAT (may be `"#N/A"` for aggregates).
#' - `EU27`: Logical EU27 membership flag.
#' - `name`: Name used in external databases.
#' - `eia`: EIA country identifier.
#' - `iea`: IEA country identifier.
#' - `water_code`: Water statistics numeric code.
#' - `water_area`: Name used in water statistics.
#' - `baci`: BACI trade database country code.
#' - `fish`: Fisheries dataset numeric code.
#' - `region_code`: Numeric regional code.
#' - `cbs`: Logical CBS dataset membership flag.
#' - `fabio_code`: FABIO database numeric code.
#' - `ADB_Region`: Asian Development Bank region.
#' - `region`: General world region.
#' - `uISO3c`: UN M49 numeric code.
#' - `Lassaletta`: Lassaletta et al. nitrogen study grouping.
#' - `region_krausmann`: Krausmann regional grouping.
#' - `region_HANPP`: HANPP study regional grouping.
#' - `region_krausmann2`: Alternative Krausmann grouping.
#' - `region_UN_sub`: UN M49 sub-region.
#' - `region_UN`: UN M49 macro-region.
#' - `region_ILO1`: ILO primary region.
#' - `region_ILO2`: ILO secondary region.
#' - `region_ILO3`: ILO tertiary region.
#' - `region_IEA`: IEA region.
#' - `region_IPCC`: IPCC region.
#' - `region_labour`: Labour-focused region.
#' - `region_labour_agg`: Aggregated labour region.
#' - `region_labour_mech`: Labour mechanisation region.
#' - `region_test`: Experimental regional grouping.
#' @seealso [polities_cats] for the subset restricted to sovereign countries.
#' @source Compiled from [FAOSTAT](https://www.fao.org/faostat/), UN M49,
#'   ILO, IEA, and other international statistical sources.
#'
#' @examples
#' head(regions_full)
"regions_full"


#' Source label to polity aliases
#'
#' @description
#' The mapping from a country or area **label**, as a source writes it, to a WHEP
#' polity. Read by [resolve_polity_label()].
#'
#' @details
#' A copy of `data/final/label_alias_map.csv` as published by whep-polities, which
#' is the authority for what a label means. It is embedded rather than resolved at
#' runtime for the same reason [polities] is: a package function cannot depend on a
#' sibling checkout existing. It is deliberately not *computed* here — a second
#' lookup in this package would be a second authority for the same question, which
#' is how the FAOSTAT area mapping came to attribute 118 area-years to polities
#' that did not exist.
#'
#' Two scopings carry the meaning, and both are load-bearing:
#'
#' - `source` — the same label can mean different things in different sources, so
#'   an alias may apply to one source only. Empty means it applies to any.
#' - `year_start` / `year_end` — a label's referent changes. `"Cape Verde"` is the
#'   Portuguese colony `CPV-1886-1975` before independence and `CPV-1975-2025`
#'   after, so it appears twice with different ranges. Empty means any year.
#'
#' @format
#' A tibble with one row per alias:
#' - `source_label`: the label as the source writes it, verbatim.
#' - `source`: source slug the alias is scoped to; empty applies to any source.
#' - `year_start`, `year_end`: inclusive year range; empty applies to any year.
#' - `polity_code`: the polity the label resolves to.
#' - `common_name`: human-readable name for that polity.
#' - `confidence`: the upstream matcher's confidence in the assignment.
#' - `observed_rows`: how many source rows were actually seen carrying this label,
#'   `0` when the label is merely mappable. Published so a consumer can tell
#'   "this label carries data" from "this label could be resolved if it did",
#'   which are different questions. `data-raw/table_mappings.R` uses it to decide
#'   which FABIO rest-of-world areas may be folded: an area that reports data must
#'   keep its own polity rather than being summed into an aggregate.
#'
#' Unlike [polities] and [polity_area_crosswalk], whose `@format` sections list
#' *key* columns, this one is exhaustive — every column is above.
#'
#' @seealso [resolve_polity_label()], [polity_area_crosswalk] for numeric codes.
#' @examples
#' head(polity_label_aliases)
"polity_label_aliases"
