#' @title Create WHEP typologies for Spain
#'
#' @description Calculates all decision variables for the WHEP typology
#' using only production and consumption data (no import/export).
#'
#' @param prod_destiny Tibble with N flows from `create_n_prov_destiny()`.
#' @param prod_n Tibble with per-item N production from `create_n_production()`
#' (column `prod`, renamed here to `production_n`).
#' @param years Numeric vector of years to include (default = 2020).
#'
#' @return A data frame with Year, Province_name, decision variables,
#' and Category.
#' @export
create_typologies_whep <- function(
  prod_destiny = create_n_prov_destiny(),
  prod_n = create_n_production() |> dplyr::rename(production_n = prod),
  years = 2020
) {
  prod_destiny <- prod_destiny |>
    dplyr::filter(
      year %in% years,
      province_name != "Sea",
      box != "Fish",
      box != "Agro-industry"
    )

  prod_n <- prod_n |>
    dplyr::filter(year %in% years, province_name != "Sea")

  # --- Feed-Import ------------------------------------------------
  # Imported feed arrives as origin "Outside" already split into the
  # ruminant/monogastric feed destinies, so it can be summed directly.
  import_feed_df <- prod_destiny |>
    dplyr::filter(
      origin == "Outside",
      destiny %in% c("livestock_mono", "livestock_rum")
    ) |>
    dplyr::group_by(year, province_name) |>
    dplyr::summarise(
      feed_import = sum(mg_n, na.rm = TRUE),
      .groups = "drop"
    )

  # --- 1. Human share ------------------------------------------------------
  food_consumption <- prod_destiny |>
    dplyr::filter(destiny %in% c("population_food", "population_other_uses")) |>
    dplyr::group_by(year, province_name) |>
    dplyr::summarise(
      food_consumption = sum(mg_n, na.rm = TRUE),
      .groups = "drop"
    )

  production <- prod_n |>
    dplyr::group_by(year, province_name) |>
    dplyr::summarise(
      production = sum(production_n, na.rm = TRUE),
      .groups = "drop"
    )

  human_share <- food_consumption |>
    dplyr::left_join(production, by = c("year", "province_name")) |>
    dplyr::mutate(
      human_share = ifelse(production > 0, food_consumption / production, NA)
    )

  # --- 2. Woody share --------------------------------------------------------
  woody_share <- prod_destiny |>
    dplyr::filter(box %in% c("Cropland", "semi_natural_agroecosystems")) |>
    dplyr::mutate(
      woody = ifelse(item %in% c("Firewood", "Acorns"), mg_n, 0)
    ) |>
    dplyr::group_by(year, province_name) |>
    dplyr::summarise(
      woody_prod = sum(woody, na.rm = TRUE),
      total_prod = sum(mg_n, na.rm = TRUE),
      .groups = "drop"
    ) |>
    dplyr::mutate(
      woody_share = ifelse(total_prod > 0, woody_prod / total_prod, NA)
    )

  # --- 3. Cropland production ------------------------------------------------
  crop_feed_list <- prod_n |>
    dplyr::filter(box == "Cropland") |>
    dplyr::group_by(year, province_name) |>
    dplyr::summarise(
      crop_prod = sum(production_n, na.rm = TRUE),
      .groups = "drop"
    )

  # --- 4. Animal ingestion / livestock feed --------------------------------
  animal_ingestion <- prod_destiny |>
    dplyr::filter(destiny %in% c("livestock_mono", "livestock_rum")) |>
    dplyr::group_by(year, province_name) |>
    dplyr::summarise(
      animal_ingestion = sum(mg_n, na.rm = TRUE),
      .groups = "drop"
    )

  # --- 5. Grass vs crop feed -------------------------------------------------
  grass_feed <- prod_destiny |>
    dplyr::filter(
      box == "semi_natural_agroecosystems",
      item == "Grassland",
      destiny %in% c("livestock_mono", "livestock_rum")
    ) |>
    dplyr::group_by(year, province_name) |>
    dplyr::summarise(
      grass_feed_N = sum(mg_n, na.rm = TRUE),
      .groups = "drop"
    )

  crop_feed <- prod_destiny |>
    dplyr::filter(
      box == "Cropland",
      destiny %in% c("livestock_mono", "livestock_rum")
    ) |>
    dplyr::group_by(year, province_name) |>
    dplyr::summarise(
      crop_feed_N = sum(mg_n, na.rm = TRUE),
      .groups = "drop"
    )

  # --- Combine all decision variables ---------------------------------------
  whep_typologies <- human_share |>
    dplyr::left_join(woody_share, by = c("year", "province_name")) |>
    dplyr::left_join(crop_feed_list, by = c("year", "province_name")) |>
    dplyr::left_join(animal_ingestion, by = c("year", "province_name")) |>
    dplyr::left_join(import_feed_df, by = c("year", "province_name")) |>
    dplyr::left_join(grass_feed, by = c("year", "province_name")) |>
    dplyr::left_join(crop_feed, by = c("year", "province_name"))

  # --- Assign WHEP Typologies ------------------------------------------------
  whep_typologies <- whep_typologies |>
    dplyr::mutate(
      import_share = feed_import / animal_ingestion,
      Category = dplyr::case_when(
        human_share > 0.9 ~ "Urban System",
        woody_share > 0.1 ~ "Woody-based system",
        import_share > 0.6 ~ "Imported feed-based system",
        crop_prod > animal_ingestion ~ "Cropland-based system",
        grass_feed_N > crop_feed_N ~ "Local grass-based livestock system",
        TRUE ~ "Local crop-based livestock system"
      )
    )

  whep_typologies
}


#' @title Plot of WHEP typology classification
#'
#' @description Generates a plot of province typologies over time based on
#' WHEP typology classification.
#'
#' @param whep_typologies A data frame returned by `create_typologies_whep()`.
#'
#' @return A plot showing province typology evolution from 1860 to 2020.
#' @noRd
.plot_whep_typologies <- function(whep_typologies = NULL) {
  if (is.null(whep_typologies)) {
    whep_typologies <- create_typologies_whep()
  }
  whep_typologies <- whep_typologies |>
    dplyr::filter(province_name != "Sea") |>
    dplyr::mutate(
      human_share = tidyr::replace_na(human_share, 0),
      woody_share = tidyr::replace_na(woody_share, 0),
      province_name = factor(
        province_name,
        levels = sort(unique(province_name), decreasing = TRUE)
      )
    )

  typology_colors <- c(
    "Urban System" = "#1E90FF",
    "Woody-based system" = "#8B4513",
    "Cropland-based system" = "#FFD700",
    "Local grass-based livestock system" = "#2E8B57",
    "Local crop-based livestock system" = "#C2B280",
    "Imported feed-based system" = "#FF6666"
  )

  ggplot2::ggplot(
    whep_typologies,
    ggplot2::aes(x = year, y = province_name, fill = Category)
  ) +
    ggplot2::geom_tile() +
    ggplot2::scale_x_continuous(
      breaks = seq(
        min(whep_typologies$year),
        max(whep_typologies$year),
        by = 20
      ),
      expand = c(0, 0)
    ) +
    ggplot2::scale_fill_manual(values = typology_colors) +
    ggplot2::labs(
      x = "Year",
      y = "Province",
      fill = "Typology",
      title = "Province type classification evolution (1860-2020)"
    ) +
    ggplot2::theme_minimal() +
    ggplot2::theme(
      axis.text.x = ggplot2::element_text(angle = 90, vjust = 0.5, hjust = 1),
      axis.text.y = ggplot2::element_text(size = 8)
    )
}
